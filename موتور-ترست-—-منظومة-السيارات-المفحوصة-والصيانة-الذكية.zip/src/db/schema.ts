import { relations } from 'drizzle-orm';
import {
  boolean,
  doublePrecision,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

// 1. Users table (linked to Firebase Auth UID + RBAC)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  name: text('name').notNull(),
  phone: text('phone').notNull().default(''),
  email: text('email').notNull().unique(),
  role: text('role').notNull().default('user'), // 'user' | 'inspector' | 'provider' | 'admin'
  walletBalance: doublePrecision('wallet_balance').notNull().default(0),
  isVerifiedProvider: boolean('is_verified_provider').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// 2. Cars table (Marketplace + Garage linked by VIN)
export const cars = pgTable('cars', {
  id: serial('id').primaryKey(),
  ownerId: integer('owner_id')
    .references(() => users.id)
    .notNull(),
  vinNumber: text('vin_number').notNull().unique(),
  brand: text('brand').notNull(),
  model: text('model').notNull(),
  year: integer('year').notNull(),
  category: text('category').notNull(), // 'ev_hybrid' | 'chinese' | 'european' | 'economy'
  price: integer('price').notNull(),
  mileage: integer('mileage').notNull(),
  status: text('status').notNull().default('available'), // 'available' | 'pending_inspection' | 'sold' | 'personal'
  isVerified: boolean('is_verified').notNull().default(false),
  batteryCapacityKwh: doublePrecision('battery_capacity_kwh'),
  rangeKm: integer('range_km'),
  transmission: text('transmission').notNull().default('أوتوماتيك'),
  fuelType: text('fuel_type').notNull().default('بنزين'),
  city: text('city').notNull().default('القاهرة'),
  imageUrl: text('image_url').notNull(),
  dailyAvgKm: integer('daily_avg_km').notNull().default(45),
  licenseExpiry: text('license_expiry'),
  insuranceExpiry: text('insurance_expiry'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// 3. InspectionReports table (150-Point Certified Inspection Reports)
export const inspectionReports = pgTable('inspection_reports', {
  id: serial('id').primaryKey(),
  carId: integer('car_id')
    .references(() => cars.id)
    .notNull(),
  inspectorId: integer('inspector_id')
    .references(() => users.id)
    .notNull(),
  overallScore: integer('overall_score').notNull(),
  engineStatus: text('engine_status').notNull(),
  transmissionStatus: text('transmission_status').notNull().default('ممتاز - 95%'),
  chassisStatus: text('chassis_status').notNull(),
  paintStatus: text('paint_status').notNull(),
  batteryHealth: integer('battery_health').notNull(),
  checklistJson: text('checklist_json'),
  notes: text('notes'),
  reportPdfUrl: text('report_pdf_url'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// 4. MaintenanceBookings table (Mobile GPS or Certified Service Center)
export const maintenanceBookings = pgTable('maintenance_bookings', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  carId: integer('car_id')
    .references(() => cars.id)
    .notNull(),
  providerId: integer('provider_id').references(() => users.id),
  providerName: text('provider_name').notNull().default('مركز موتور ترست المعتمد'),
  serviceType: text('service_type').notNull(),
  locationType: text('location_type').notNull(), // 'mobile_gps' | 'service_center'
  addressText: text('address_text').notNull().default('القاهرة الجديدة - التجمع الخامس'),
  lat: doublePrecision('lat').notNull(),
  lng: doublePrecision('lng').notNull(),
  scheduledAt: timestamp('scheduled_at').notNull(),
  status: text('status').notNull().default('pending'), // 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled'
  totalCost: doublePrecision('total_cost').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// 5. MaintenanceHistory table (Tamper-Proof Car Digital Passport linked to VIN)
export const maintenanceHistory = pgTable('maintenance_history', {
  id: serial('id').primaryKey(),
  vinNumber: text('vin_number').notNull(),
  bookingId: integer('booking_id').references(() => maintenanceBookings.id),
  description: text('description').notNull(),
  partsReplaced: text('parts_replaced').notNull().default(''),
  mileageAtService: integer('mileage_at_service').notNull(),
  verifiedByProvider: text('verified_by_provider').notNull(),
  serviceDate: timestamp('service_date').defaultNow().notNull(),
});

// 6. EmergencyRequests table (SOS / Road Rescue & Tow Truck)
export const emergencyRequests = pgTable('emergency_requests', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  carId: integer('car_id').references(() => cars.id),
  issueType: text('issue_type').notNull(), // 'tow_truck' | 'battery' | 'tire' | 'fuel' | 'electrical'
  lat: doublePrecision('lat').notNull(),
  lng: doublePrecision('lng').notNull(),
  addressText: text('address_text').notNull().default('طريق السويس الصحراوي'),
  driverId: integer('driver_id').references(() => users.id),
  driverName: text('driver_name').notNull().default('كابتن أحمد منصور — ونش إنقاذ #14'),
  etaMinutes: integer('eta_minutes').notNull().default(14),
  status: text('status').notNull().default('dispatched'), // 'dispatched' | 'en_route' | 'arrived' | 'resolved'
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Relational definitions
export const usersRelations = relations(users, ({ many }) => ({
  cars: many(cars),
  inspections: many(inspectionReports),
  bookings: many(maintenanceBookings),
  emergencies: many(emergencyRequests),
}));

export const carsRelations = relations(cars, ({ one, many }) => ({
  owner: one(users, {
    fields: [cars.ownerId],
    references: [users.id],
  }),
  inspectionReports: many(inspectionReports),
  maintenanceBookings: many(maintenanceBookings),
}));

export const inspectionReportsRelations = relations(inspectionReports, ({ one }) => ({
  car: one(cars, {
    fields: [inspectionReports.carId],
    references: [cars.id],
  }),
  inspector: one(users, {
    fields: [inspectionReports.inspectorId],
    references: [users.id],
  }),
}));

export const maintenanceBookingsRelations = relations(maintenanceBookings, ({ one, many }) => ({
  user: one(users, {
    fields: [maintenanceBookings.userId],
    references: [users.id],
  }),
  car: one(cars, {
    fields: [maintenanceBookings.carId],
    references: [cars.id],
  }),
  provider: one(users, {
    fields: [maintenanceBookings.providerId],
    references: [users.id],
  }),
  historyEntries: many(maintenanceHistory),
}));

export const maintenanceHistoryRelations = relations(maintenanceHistory, ({ one }) => ({
  booking: one(maintenanceBookings, {
    fields: [maintenanceHistory.bookingId],
    references: [maintenanceBookings.id],
  }),
}));

export const emergencyRequestsRelations = relations(emergencyRequests, ({ one }) => ({
  user: one(users, {
    fields: [emergencyRequests.userId],
    references: [users.id],
  }),
  car: one(cars, {
    fields: [emergencyRequests.carId],
    references: [cars.id],
  }),
}));
