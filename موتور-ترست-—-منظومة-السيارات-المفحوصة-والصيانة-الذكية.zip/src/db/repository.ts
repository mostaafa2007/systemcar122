import { desc, eq, sql } from 'drizzle-orm';
import { db } from './index.ts';
import {
  cars,
  emergencyRequests,
  inspectionReports,
  maintenanceBookings,
  maintenanceHistory,
  users,
} from './schema.ts';

const OWNER_ADMIN_EMAIL = 'engcybers@gmail.com';

export async function getOrCreateUser(params: {
  uid: string;
  email: string;
  name?: string;
}) {
  try {
    const normalizedEmail = params.email.toLowerCase();
    const displayName =
      params.name && params.name.trim().length > 0
        ? params.name.trim()
        : normalizedEmail.split('@')[0];

    const existingByUid = await db
      .select()
      .from(users)
      .where(eq(users.uid, params.uid))
      .limit(1);

    if (existingByUid.length > 0) {
      const current = existingByUid[0];
      if (normalizedEmail === OWNER_ADMIN_EMAIL && current.role !== 'admin') {
        const updated = await db
          .update(users)
          .set({ role: 'admin', isVerifiedProvider: true })
          .where(eq(users.id, current.id))
          .returning();
        return updated[0];
      }
      return current;
    }

    const defaultRole = normalizedEmail === OWNER_ADMIN_EMAIL ? 'admin' : 'user';

    const inserted = await db
      .insert(users)
      .values({
        uid: params.uid,
        email: normalizedEmail,
        name: displayName,
        role: defaultRole,
        isVerifiedProvider: defaultRole === 'admin',
        walletBalance: defaultRole === 'admin' ? 50000 : 2500,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: normalizedEmail,
          name: displayName,
        },
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('Database query failed in getOrCreateUser:', error);
    throw new Error('تعذر مزامنة بيانات الحساب في قاعدة البيانات.', { cause: error });
  }
}

export async function updateUserProfile(userId: number, data: { name?: string; phone?: string }) {
  try {
    const updates: Partial<typeof users.$inferInsert> = {};
    if (data.name !== undefined) updates.name = data.name;
    if (data.phone !== undefined) updates.phone = data.phone;

    const updated = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, userId))
      .returning();
    return updated[0] ?? null;
  } catch (error) {
    console.error('Database query failed in updateUserProfile:', error);
    throw new Error('تعذر تحديث الملف الشخصي.', { cause: error });
  }
}

export async function listMarketplaceCars(filters: {
  category?: string;
  minBattery?: number;
  minRange?: number;
  maxPrice?: number;
  search?: string;
  includePending?: boolean;
  ownerId?: number;
}) {
  try {
    const allCars = await db
      .select({
        car: cars,
        ownerName: users.name,
        ownerPhone: users.phone,
      })
      .from(cars)
      .innerJoin(users, eq(cars.ownerId, users.id))
      .orderBy(desc(cars.createdAt));

    const allReports = await db
      .select({
        report: inspectionReports,
        inspectorName: users.name,
      })
      .from(inspectionReports)
      .innerJoin(users, eq(inspectionReports.inspectorId, users.id))
      .orderBy(desc(inspectionReports.createdAt));

    const historyCounts = await db
      .select({
        vinNumber: maintenanceHistory.vinNumber,
        count: sql<number>`count(*)::int`,
      })
      .from(maintenanceHistory)
      .groupBy(maintenanceHistory.vinNumber);

    const reportByCarId = new Map<number, (typeof allReports)[number]>();
    for (const r of allReports) {
      if (!reportByCarId.has(r.report.carId)) {
        reportByCarId.set(r.report.carId, r);
      }
    }

    const countByVin = new Map<string, number>();
    for (const row of historyCounts) {
      countByVin.set(row.vinNumber, Number(row.count));
    }

    const searchLower = filters.search?.trim().toLowerCase() || '';

    return allCars
      .filter(({ car }) => {
        if (filters.ownerId !== undefined) {
          return car.ownerId === filters.ownerId;
        }
        if (!filters.includePending && car.status === 'personal') {
          return false;
        }
        if (filters.category && filters.category !== 'all' && car.category !== filters.category) {
          return false;
        }
        if (
          filters.minBattery !== undefined &&
          filters.minBattery > 0 &&
          (car.batteryCapacityKwh === null || car.batteryCapacityKwh < filters.minBattery)
        ) {
          return false;
        }
        if (
          filters.minRange !== undefined &&
          filters.minRange > 0 &&
          (car.rangeKm === null || car.rangeKm < filters.minRange)
        ) {
          return false;
        }
        if (filters.maxPrice !== undefined && filters.maxPrice > 0 && car.price > filters.maxPrice) {
          return false;
        }
        if (searchLower) {
          const hay = `${car.brand} ${car.model} ${car.year} ${car.vinNumber} ${car.city}`.toLowerCase();
          if (!hay.includes(searchLower)) return false;
        }
        return true;
      })
      .map(({ car, ownerName, ownerPhone }) => {
        const rep = reportByCarId.get(car.id);
        return {
          ...car,
          ownerName,
          ownerPhone,
          latestInspection: rep
            ? {
                ...rep.report,
                inspectorName: rep.inspectorName,
              }
            : null,
          verifiedServiceCount: countByVin.get(car.vinNumber) ?? 0,
        };
      });
  } catch (error) {
    console.error('Database query failed in listMarketplaceCars:', error);
    throw new Error('تعذر تحميل قائمة السيارات حالياً.', { cause: error });
  }
}

export async function getCarById(carId: number) {
  try {
    const rows = await listMarketplaceCars({ includePending: true });
    return rows.find((c) => c.id === carId) ?? null;
  } catch (error) {
    console.error('Database query failed in getCarById:', error);
    throw new Error('تعذر تحميل تفاصيل السيارة.', { cause: error });
  }
}

export async function createCarListing(data: {
  ownerId: number;
  vinNumber: string;
  brand: string;
  model: string;
  year: number;
  category: string;
  price: number;
  mileage: number;
  requestInspection: boolean;
  batteryCapacityKwh?: number | null;
  rangeKm?: number | null;
  transmission?: string;
  fuelType?: string;
  city?: string;
  imageUrl: string;
  dailyAvgKm?: number;
  licenseExpiry?: string | null;
  insuranceExpiry?: string | null;
}) {
  try {
    const inserted = await db
      .insert(cars)
      .values({
        ownerId: data.ownerId,
        vinNumber: data.vinNumber.toUpperCase().trim(),
        brand: data.brand.trim(),
        model: data.model.trim(),
        year: data.year,
        category: data.category,
        price: data.price,
        mileage: data.mileage,
        status: data.requestInspection ? 'pending_inspection' : 'available',
        isVerified: false,
        batteryCapacityKwh: data.batteryCapacityKwh ?? null,
        rangeKm: data.rangeKm ?? null,
        transmission: data.transmission || 'أوتوماتيك',
        fuelType: data.fuelType || (data.category === 'ev_hybrid' ? 'كهرباء بالكامل' : 'بنزين'),
        city: data.city || 'القاهرة',
        imageUrl: data.imageUrl,
        dailyAvgKm: data.dailyAvgKm ?? 45,
        licenseExpiry: data.licenseExpiry ?? '2027-06-01',
        insuranceExpiry: data.insuranceExpiry ?? '2027-06-01',
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('Database query failed in createCarListing:', error);
    throw new Error('تعذر حفظ بيانات السيارة. يرجى التأكد من عدم تكرار رقم الشاسيه (VIN).', {
      cause: error,
    });
  }
}

export async function submitInspectionReport(data: {
  carId: number;
  inspectorId: number;
  inspectorName: string;
  overallScore: number;
  engineStatus: string;
  transmissionStatus: string;
  chassisStatus: string;
  paintStatus: string;
  batteryHealth: number;
  checklistJson: string;
  notes: string;
}) {
  try {
    const existingCar = await db.select().from(cars).where(eq(cars.id, data.carId)).limit(1);
    if (existingCar.length === 0) {
      throw new Error('السيارة غير موجودة.');
    }
    const targetCar = existingCar[0];

    const reportRows = await db
      .insert(inspectionReports)
      .values({
        carId: data.carId,
        inspectorId: data.inspectorId,
        overallScore: data.overallScore,
        engineStatus: data.engineStatus,
        transmissionStatus: data.transmissionStatus,
        chassisStatus: data.chassisStatus,
        paintStatus: data.paintStatus,
        batteryHealth: data.batteryHealth,
        checklistJson: data.checklistJson,
        notes: data.notes,
        reportPdfUrl: `/reports/${targetCar.vinNumber}-${Date.now()}.pdf`,
      })
      .returning();

    await db
      .update(cars)
      .set({
        isVerified: true,
        status: targetCar.status === 'pending_inspection' ? 'available' : targetCar.status,
      })
      .where(eq(cars.id, data.carId));

    await db.insert(maintenanceHistory).values({
      vinNumber: targetCar.vinNumber,
      bookingId: null,
      description: `فحص فني شامل ومعتمد (150 نقطة) — النتيجة الإجمالية ${data.overallScore}%`,
      partsReplaced: `الموتور: ${data.engineStatus} | الشاسيه: ${data.chassisStatus}`,
      mileageAtService: targetCar.mileage,
      verifiedByProvider: `${data.inspectorName} — مهندس فحص فني معتمد`,
    });

    return reportRows[0];
  } catch (error) {
    console.error('Database query failed in submitInspectionReport:', error);
    throw new Error('تعذر إصدار تقرير الفحص الفني حالياً.', { cause: error });
  }
}

export async function listMaintenanceBookings(params: { userId?: number; role: string }) {
  try {
    const rows = await db
      .select({
        booking: maintenanceBookings,
        carBrand: cars.brand,
        carModel: cars.model,
        carYear: cars.year,
        vinNumber: cars.vinNumber,
        customerName: users.name,
      })
      .from(maintenanceBookings)
      .innerJoin(cars, eq(maintenanceBookings.carId, cars.id))
      .innerJoin(users, eq(maintenanceBookings.userId, users.id))
      .orderBy(desc(maintenanceBookings.createdAt));

    const filtered =
      params.role === 'admin' || params.role === 'provider'
        ? rows
        : rows.filter((r) => r.booking.userId === params.userId);

    return filtered.map((r) => ({
      ...r.booking,
      carTitle: `${r.carBrand} ${r.carModel} ${r.carYear}`,
      vinNumber: r.vinNumber,
      customerName: r.customerName,
    }));
  } catch (error) {
    console.error('Database query failed in listMaintenanceBookings:', error);
    throw new Error('تعذر تحميل حجوزات الصيانة.', { cause: error });
  }
}

export async function createMaintenanceBooking(data: {
  userId: number;
  carId: number;
  serviceType: string;
  locationType: 'mobile_gps' | 'service_center';
  providerName: string;
  addressText: string;
  lat: number;
  lng: number;
  scheduledAt: Date;
  totalCost: number;
}) {
  try {
    const inserted = await db
      .insert(maintenanceBookings)
      .values({
        userId: data.userId,
        carId: data.carId,
        providerName: data.providerName,
        serviceType: data.serviceType,
        locationType: data.locationType,
        addressText: data.addressText,
        lat: data.lat,
        lng: data.lng,
        scheduledAt: data.scheduledAt,
        status: 'pending',
        totalCost: data.totalCost,
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('Database query failed in createMaintenanceBooking:', error);
    throw new Error('تعذر إنشاء حجز الصيانة.', { cause: error });
  }
}

export async function updateMaintenanceBookingStatus(data: {
  bookingId: number;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  totalCost?: number;
  partsReplaced?: string;
  mileageAtService?: number;
  providerLabel: string;
}) {
  try {
    const existing = await db
      .select()
      .from(maintenanceBookings)
      .where(eq(maintenanceBookings.id, data.bookingId))
      .limit(1);

    if (existing.length === 0) return null;
    const booking = existing[0];

    const updated = await db
      .update(maintenanceBookings)
      .set({
        status: data.status,
        totalCost: data.totalCost !== undefined ? data.totalCost : booking.totalCost,
      })
      .where(eq(maintenanceBookings.id, data.bookingId))
      .returning();

    if (data.status === 'completed') {
      const carRows = await db.select().from(cars).where(eq(cars.id, booking.carId)).limit(1);
      if (carRows.length > 0) {
        const car = carRows[0];
        const recordedMileage = data.mileageAtService ?? car.mileage;

        await db.insert(maintenanceHistory).values({
          vinNumber: car.vinNumber,
          bookingId: booking.id,
          description: `${booking.serviceType} (${booking.locationType === 'mobile_gps' ? 'صيانة متنقلة GPS' : 'مركز صيانة معتمد'})`,
          partsReplaced: data.partsReplaced?.trim() || 'فحص شامل وتغيير مستهلكات قياسية معتمدة',
          mileageAtService: recordedMileage,
          verifiedByProvider: data.providerLabel || booking.providerName,
        });

        if (recordedMileage > car.mileage) {
          await db.update(cars).set({ mileage: recordedMileage }).where(eq(cars.id, car.id));
        }
      }
    }

    return updated[0];
  } catch (error) {
    console.error('Database query failed in updateMaintenanceBookingStatus:', error);
    throw new Error('تعذر تحديث حالة حجز الصيانة.', { cause: error });
  }
}

export async function getDigitalPassportByVin(vinRaw: string) {
  try {
    const vin = vinRaw.toUpperCase().trim();
    const allCars = await listMarketplaceCars({ includePending: true });
    const car = allCars.find((c) => c.vinNumber.toUpperCase() === vin);
    if (!car) return null;

    const reports = await db
      .select({
        report: inspectionReports,
        inspectorName: users.name,
      })
      .from(inspectionReports)
      .innerJoin(users, eq(inspectionReports.inspectorId, users.id))
      .where(eq(inspectionReports.carId, car.id))
      .orderBy(desc(inspectionReports.createdAt));

    const history = await db
      .select()
      .from(maintenanceHistory)
      .where(eq(maintenanceHistory.vinNumber, car.vinNumber))
      .orderBy(desc(maintenanceHistory.serviceDate));

    const serviceIntervalKm = car.category === 'ev_hybrid' ? 15000 : 10000;
    const nextServiceMileage =
      (Math.floor(car.mileage / serviceIntervalKm) + 1) * serviceIntervalKm;
    const remainingKm = Math.max(250, nextServiceMileage - car.mileage);
    const dailyKm = Math.max(15, car.dailyAvgKm || 45);
    const estimatedServiceDays = Math.ceil(remainingKm / dailyKm);
    const estDate = new Date(Date.now() + estimatedServiceDays * 24 * 60 * 60 * 1000);

    return {
      car,
      inspections: reports.map((r) => ({
        ...r.report,
        inspectorName: r.inspectorName,
      })),
      history,
      reminders: {
        nextServiceMileage,
        remainingKm,
        estimatedServiceDays,
        estimatedServiceDate: estDate.toISOString().split('T')[0],
        licenseExpiry: car.licenseExpiry,
        insuranceExpiry: car.insuranceExpiry,
      },
    };
  } catch (error) {
    console.error('Database query failed in getDigitalPassportByVin:', error);
    throw new Error('تعذر استرجاع جواز السفر الرقمي للسيارة.', { cause: error });
  }
}

export async function listEmergencyRequests(params: { userId?: number; role: string }) {
  try {
    const rows = await db
      .select({
        req: emergencyRequests,
        customerName: users.name,
      })
      .from(emergencyRequests)
      .innerJoin(users, eq(emergencyRequests.userId, users.id))
      .orderBy(desc(emergencyRequests.createdAt));

    const filtered =
      params.role === 'admin' || params.role === 'provider'
        ? rows
        : rows.filter((r) => r.req.userId === params.userId);

    return filtered.map((r) => ({
      ...r.req,
      customerName: r.customerName,
    }));
  } catch (error) {
    console.error('Database query failed in listEmergencyRequests:', error);
    throw new Error('تعذر تحميل طلبات الطوارئ.', { cause: error });
  }
}

export async function createEmergencyRequest(data: {
  userId: number;
  carId?: number | null;
  issueType: 'tow_truck' | 'battery' | 'tire' | 'fuel' | 'electrical';
  lat: number;
  lng: number;
  addressText: string;
}) {
  try {
    const dispatchers: Record<string, { driver: string; eta: number }> = {
      tow_truck: { driver: 'كابتن أحمد منصور — ونش هيدروليك #14', eta: 14 },
      battery: { driver: 'فني محمود سالم — وحدة بطاريات متنقلة #07', eta: 11 },
      tire: { driver: 'فني يوسف عادل — خدمة إطارات سريعة #09', eta: 12 },
      fuel: { driver: 'فني سامح طارق — توصيل وقود فوري #04', eta: 10 },
      electrical: { driver: 'م. عمر الشريف — وحدة فحص كهرباء #03', eta: 16 },
    };

    const assigned = dispatchers[data.issueType] ?? dispatchers.tow_truck;

    const inserted = await db
      .insert(emergencyRequests)
      .values({
        userId: data.userId,
        carId: data.carId ?? null,
        issueType: data.issueType,
        lat: data.lat,
        lng: data.lng,
        addressText: data.addressText,
        driverName: assigned.driver,
        etaMinutes: assigned.eta,
        status: 'dispatched',
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('Database query failed in createEmergencyRequest:', error);
    throw new Error('تعذر إرسال بلاغ طوارئ الطريق.', { cause: error });
  }
}

export async function updateEmergencyStatus(
  id: number,
  status: 'dispatched' | 'en_route' | 'arrived' | 'resolved'
) {
  try {
    const etaMap: Record<string, number> = {
      dispatched: 14,
      en_route: 7,
      arrived: 0,
      resolved: 0,
    };
    const updated = await db
      .update(emergencyRequests)
      .set({ status, etaMinutes: etaMap[status] ?? 0 })
      .where(eq(emergencyRequests.id, id))
      .returning();

    return updated[0] ?? null;
  } catch (error) {
    console.error('Database query failed in updateEmergencyStatus:', error);
    throw new Error('تعذر تحديث حالة طلب الطوارئ.', { cause: error });
  }
}

export async function getAdminOverview() {
  try {
    const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));
    const allCars = await db.select().from(cars);
    const bookings = await listMaintenanceBookings({ role: 'admin' });
    const emergencies = await listEmergencyRequests({ role: 'admin' });

    const grossCars = allCars.reduce((acc, c) => acc + c.price, 0);
    const grossMaintenance = bookings.reduce((acc, b) => acc + b.totalCost, 0);
    const estimatedCommissionEgp = Math.round(grossCars * 0.015 + grossMaintenance * 0.12);

    return {
      stats: {
        totalUsers: allUsers.length,
        totalCars: allCars.length,
        verifiedCars: allCars.filter((c) => c.isVerified).length,
        pendingInspections: allCars.filter((c) => c.status === 'pending_inspection' || !c.isVerified)
          .length,
        totalBookings: bookings.length,
        activeEmergencies: emergencies.filter((e) => e.status !== 'resolved').length,
        grossVolumeEgp: grossCars + grossMaintenance,
        estimatedCommissionEgp,
      },
      users: allUsers,
      recentBookings: bookings.slice(0, 10),
      recentEmergencies: emergencies.slice(0, 10),
    };
  } catch (error) {
    console.error('Database query failed in getAdminOverview:', error);
    throw new Error('تعذر تحميل بيانات لوحة المدير العام.', { cause: error });
  }
}

export async function adminUpdateUserRole(
  targetUserId: number,
  role: 'user' | 'inspector' | 'provider' | 'admin',
  isVerifiedProvider?: boolean
) {
  try {
    const updates: Partial<typeof users.$inferInsert> = { role };
    if (isVerifiedProvider !== undefined) {
      updates.isVerifiedProvider = isVerifiedProvider;
    } else {
      updates.isVerifiedProvider = role === 'inspector' || role === 'provider' || role === 'admin';
    }

    const updated = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, targetUserId))
      .returning();

    return updated[0] ?? null;
  } catch (error) {
    console.error('Database query failed in adminUpdateUserRole:', error);
    throw new Error('تعذر تعديل صلاحية المستخدم.', { cause: error });
  }
}
