import { useCallback, useEffect, useState } from 'react';
import {
  Car,
  FileCheck2,
  Home,
  Moon,
  Sun,
  User,
  Wrench,
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AccountSubTab, AccountWorkspaceView } from './components/AccountWorkspaceView';
import { HomeView } from './components/HomeView';
import { MaintenanceView } from './components/MaintenanceView';
import { MarketplaceView } from './components/MarketplaceView';
import { PassportView } from './components/PassportView';
import { CarCategory, CarListingDTO } from './types';

type NavTab = 'home' | 'marketplace' | 'maintenance' | 'passport' | 'account';

function MotorTrustApp() {
  const { firebaseUser, profile, signInWithGoogle } = useAuth();

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [activeCategory, setActiveCategory] = useState<CarCategory>('all');
  const [cars, setCars] = useState<CarListingDTO[]>([]);
  const [loadingCars, setLoadingCars] = useState(true);
  const [carsError, setCarsError] = useState<string | null>(null);
  const [selectedCar, setSelectedCar] = useState<CarListingDTO | null>(null);
  const [passportVin, setPassportVin] = useState<string | null>(null);
  const [maintenanceMode, setMaintenanceMode] = useState<'booking' | 'sos'>('booking');
  const [accountSubTab, setAccountSubTab] = useState<AccountSubTab>('profile');
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode((prev) => {
      const next = !prev;
      document.documentElement.classList.toggle('dark', next);
      return next;
    });
  };

  const fetchCars = useCallback(async () => {
    setLoadingCars(true);
    setCarsError(null);
    try {
      const res = await fetch('/api/cars?includePending=true');
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تحميل بيانات السيارات.');
      setCars(data.cars || []);
    } catch (err: any) {
      setCarsError(err.message || 'تعذر الاتصال بالخادم.');
    } finally {
      setLoadingCars(false);
    }
  }, []);

  useEffect(() => {
    void fetchCars();
  }, [fetchCars]);

  const handleNavigate = (tab: NavTab, subAction?: string) => {
    setActiveTab(tab);
    if (tab === 'maintenance') {
      setMaintenanceMode(subAction === 'sos' ? 'sos' : 'booking');
    }
    if (tab === 'account' && subAction) {
      setAccountSubTab(subAction as AccountSubTab);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCar = (car: CarListingDTO) => {
    setSelectedCar(car);
    setActiveTab('marketplace');
  };

  const handleOpenPassport = (vin: string) => {
    setPassportVin(vin);
    setActiveTab('passport');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navItems: Array<{ id: NavTab; label: string; icon: typeof Home }> = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'marketplace', label: 'السوق', icon: Car },
    { id: 'maintenance', label: 'الصيانة', icon: Wrench },
    { id: 'passport', label: 'سيارتي', icon: FileCheck2 },
    { id: 'account', label: 'حسابي', icon: User },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Strict 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line brand wordmark */}
          <button
            type="button"
            onClick={() => handleNavigate('home')}
            className="text-xl font-extrabold tracking-tight text-[#1E40AF] dark:text-blue-400 whitespace-nowrap shrink-0 cursor-pointer"
          >
            موتور ترست
          </button>

          {/* Zone 2: 5 concise single-line text nav links */}
          <nav
            className="hidden md:flex items-center gap-7 text-sm font-bold"
            aria-label="التنقل الرئيسي"
          >
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
                    active
                      ? 'text-[#1E40AF] dark:text-blue-400 border-[#F59E0B]'
                      : 'text-slate-600 dark:text-slate-300 border-transparent hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="shrink-0">
            {firebaseUser ? (
              <button
                type="button"
                onClick={() => handleNavigate('account', 'profile')}
                className="px-4 py-2 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer max-w-[160px] truncate"
              >
                {profile?.name || 'لوحة حسابي'}
              </button>
            ) : (
              <button
                type="button"
                onClick={signInWithGoogle}
                className="px-4 py-2 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                تسجيل الدخول
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8 pb-20 md:pb-12">
        {carsError && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm font-bold flex items-center justify-between gap-3">
            <span>{carsError}</span>
            <button
              type="button"
              onClick={fetchCars}
              className="px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-bold cursor-pointer"
            >
              إعادة المحاولة
            </button>
          </div>
        )}

        {activeTab === 'home' && (
          <HomeView
            cars={cars}
            loading={loadingCars}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
            onSelectCar={handleSelectCar}
            onNavigate={handleNavigate}
          />
        )}

        {activeTab === 'marketplace' && (
          <MarketplaceView
            cars={cars}
            loading={loadingCars}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
            selectedCar={selectedCar}
            onSelectCar={setSelectedCar}
            onOpenPassport={handleOpenPassport}
            onCarsUpdated={fetchCars}
          />
        )}

        {activeTab === 'maintenance' && (
          <MaintenanceView cars={cars} initialMode={maintenanceMode} />
        )}

        {activeTab === 'passport' && (
          <PassportView cars={cars} initialVin={passportVin} />
        )}

        {activeTab === 'account' && (
          <AccountWorkspaceView
            cars={cars}
            initialSubTab={accountSubTab}
            darkMode={darkMode}
            onToggleDarkMode={toggleDarkMode}
            onRefreshAll={fetchCars}
          />
        )}
      </main>

      {/* Quiet Footer with Theme Toggle & Quick Portal Links */}
      <footer className="hidden md:block border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="font-bold text-slate-700 dark:text-slate-300">
            موتور ترست — منظومة السيارات المفحوصة والصيانة الذكية وجواز السفر الرقمي
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => handleNavigate('account', 'inspector')}
              className="hover:text-[#1E40AF] dark:hover:text-blue-400 font-medium cursor-pointer"
            >
              نموذج الفحص 150 نقطة
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('account', 'architecture')}
              className="hover:text-[#1E40AF] dark:hover:text-blue-400 font-medium cursor-pointer"
            >
              هيكلية النظام
            </button>
            <button
              type="button"
              onClick={toggleDarkMode}
              className="inline-flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-200 hover:text-[#1E40AF] cursor-pointer"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5 text-[#F59E0B]" /> : <Moon className="w-3.5 h-3.5 text-[#1E40AF]" />}
              {darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar (<= 56px, exact 5 tabs requested) */}
      <nav
        className="md:hidden fixed bottom-0 inset-x-0 z-40 h-14 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 grid grid-cols-5"
        aria-label="شريط التنقل السفلي"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavigate(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold transition-colors cursor-pointer ${
                active
                  ? 'text-[#1E40AF] dark:text-blue-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className={`w-4 h-4 ${active ? 'text-[#F59E0B]' : ''}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MotorTrustApp />
    </AuthProvider>
  );
}
