import { NextFunction, Request, Response } from 'express';
import { DecodedIdToken } from 'firebase-admin/auth';
import { adminAuth } from '../lib/firebase-admin.ts';
import { getOrCreateUser } from '../db/repository.ts';

export interface DbUserRecord {
  id: number;
  uid: string;
  name: string;
  phone: string;
  email: string;
  role: string;
  walletBalance: number;
  isVerifiedProvider: boolean;
  createdAt: Date;
}

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
  dbUser?: DbUserRecord;
}

export const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة.' });
  }

  const token = authHeader.split('Bearer ')[1];
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = decodedToken;

    const dbUser = await getOrCreateUser({
      uid: decodedToken.uid,
      email: decodedToken.email || `${decodedToken.uid}@motortrust.local`,
      name: decodedToken.name,
    });
    req.dbUser = dbUser;
    next();
  } catch (error) {
    console.error('Error verifying Firebase ID token:', error);
    return res.status(401).json({ error: 'جلسة الدخول غير صالحة أو منتهية.' });
  }
};

export const requireRole = (allowedRoles: Array<'user' | 'inspector' | 'provider' | 'admin'>) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.dbUser) {
      return res.status(401).json({ error: 'يرجى تسجيل الدخول أولاً.' });
    }
    const role = req.dbUser.role as 'user' | 'inspector' | 'provider' | 'admin';
    if (!allowedRoles.includes(role)) {
      return res.status(403).json({
        error: 'ليس لديك الصلاحية المطلوبة لتنفيذ هذا الإجراء.',
      });
    }
    next();
  };
};
