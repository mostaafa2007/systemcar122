export type UserRole = 'user' | 'inspector' | 'provider' | 'admin';

export type CarCategory = 'all' | 'ev_hybrid' | 'chinese' | 'european' | 'economy';

export interface UserProfile {
  id: number;
  uid: string;
  name: string;
  phone: string;
  email: string;
  role: UserRole;
  walletBalance: number;
  isVerifiedProvider: boolean;
  createdAt: string;
}

export interface InspectionReportDTO {
  id: number;
  carId: number;
  inspectorId: number;
  inspectorName?: string;
  overallScore: number;
  engineStatus: string;
  transmissionStatus: string;
  chassisStatus: string;
  paintStatus: string;
  batteryHealth: number;
  checklistJson?: string | null;
  notes?: string | null;
  reportPdfUrl?: string | null;
  createdAt: string;
}

export interface CarListingDTO {
  id: number;
  ownerId: number;
  ownerName?: string;
  ownerPhone?: string;
  vinNumber: string;
  brand: string;
  model: string;
  year: number;
  category: Exclude<CarCategory, 'all'>;
  price: number;
  mileage: number;
  status: 'available' | 'pending_inspection' | 'sold' | 'personal';
  isVerified: boolean;
  batteryCapacityKwh: number | null;
  rangeKm: number | null;
  transmission: string;
  fuelType: string;
  city: string;
  imageUrl: string;
  dailyAvgKm: number;
  licenseExpiry: string | null;
  insuranceExpiry: string | null;
  createdAt: string;
  latestInspection: InspectionReportDTO | null;
  verifiedServiceCount: number;
}

export interface MaintenanceBookingDTO {
  id: number;
  userId: number;
  carId: number;
  carTitle?: string;
  vinNumber?: string;
  customerName?: string;
  providerId: number | null;
  providerName: string;
  serviceType: string;
  locationType: 'mobile_gps' | 'service_center';
  addressText: string;
  lat: number;
  lng: number;
  scheduledAt: string;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  totalCost: number;
  createdAt: string;
}

export interface MaintenanceHistoryDTO {
  id: number;
  vinNumber: string;
  bookingId: number | null;
  description: string;
  partsReplaced: string;
  mileageAtService: number;
  verifiedByProvider: string;
  serviceDate: string;
}

export interface EmergencyRequestDTO {
  id: number;
  userId: number;
  carId: number | null;
  customerName?: string;
  issueType: 'tow_truck' | 'battery' | 'tire' | 'fuel' | 'electrical';
  lat: number;
  lng: number;
  addressText: string;
  driverId: number | null;
  driverName: string;
  etaMinutes: number;
  status: 'dispatched' | 'en_route' | 'arrived' | 'resolved';
  createdAt: string;
}

export interface PassportResponseDTO {
  car: CarListingDTO;
  inspections: InspectionReportDTO[];
  history: MaintenanceHistoryDTO[];
  reminders: {
    nextServiceMileage: number;
    remainingKm: number;
    estimatedServiceDays: number;
    estimatedServiceDate: string;
    licenseExpiry: string | null;
    insuranceExpiry: string | null;
  };
}

export interface FairPriceEstimateDTO {
  minPrice: number;
  fairPrice: number;
  maxPrice: number;
  confidence: number;
  factors: string[];
}

export interface AdminOverviewDTO {
  stats: {
    totalUsers: number;
    totalCars: number;
    verifiedCars: number;
    pendingInspections: number;
    totalBookings: number;
    activeEmergencies: number;
    grossVolumeEgp: number;
    estimatedCommissionEgp: number;
  };
  users: UserProfile[];
  recentBookings: MaintenanceBookingDTO[];
  recentEmergencies: EmergencyRequestDTO[];
}
