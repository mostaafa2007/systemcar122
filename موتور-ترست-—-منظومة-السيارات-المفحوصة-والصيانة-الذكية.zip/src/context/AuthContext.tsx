import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User as FirebaseUser } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import {
  CarListingDTO,
  EmergencyRequestDTO,
  MaintenanceBookingDTO,
  UserProfile,
} from '../types';

interface AuthContextValue {
  firebaseUser: FirebaseUser | null;
  profile: UserProfile | null;
  ownedCars: CarListingDTO[];
  myBookings: MaintenanceBookingDTO[];
  myEmergencies: EmergencyRequestDTO[];
  loading: boolean;
  authError: string | null;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  authFetch: (input: string, init?: RequestInit) => Promise<Response>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [ownedCars, setOwnedCars] = useState<CarListingDTO[]>([]);
  const [myBookings, setMyBookings] = useState<MaintenanceBookingDTO[]>([]);
  const [myEmergencies, setMyEmergencies] = useState<EmergencyRequestDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const tokenRef = useRef<string | null>(null);

  const authFetch = useCallback(async (input: string, init: RequestInit = {}) => {
    const currentUser = auth.currentUser;
    let token = tokenRef.current;
    if (currentUser) {
      token = await currentUser.getIdToken();
      tokenRef.current = token;
    }

    const headers = new Headers(init.headers);
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    if (init.body && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }

    return fetch(input, {
      ...init,
      headers,
    });
  }, []);

  const refreshProfile = useCallback(async () => {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      setProfile(null);
      setOwnedCars([]);
      setMyBookings([]);
      setMyEmergencies([]);
      return;
    }

    try {
      const res = await authFetch('/api/me');
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'تعذر مزامنة بيانات الحساب.');
      }
      const data = await res.json();
      setProfile(data.user);
      setOwnedCars(data.ownedCars || []);
      setMyBookings(data.bookings || []);
      setMyEmergencies(data.emergencies || []);
      setAuthError(null);
    } catch (error: any) {
      setAuthError(error.message || 'تعذر الاتصال بالخادم.');
    }
  }, [authFetch]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          tokenRef.current = await user.getIdToken();
          await refreshProfile();
        } catch (err) {
          console.error('Auth sync error:', err);
        }
      } else {
        tokenRef.current = null;
        setProfile(null);
        setOwnedCars([]);
        setMyBookings([]);
        setMyEmergencies([]);
      }
      setLoading(false);
    });

    return () => unsub();
  }, [refreshProfile]);

  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    try {
      const cred = await signInWithPopup(auth, googleAuthProvider);
      tokenRef.current = await cred.user.getIdToken();
      await refreshProfile();
    } catch (error: any) {
      if (error?.code !== 'auth/popup-closed-by-user') {
        setAuthError('تعذر إتمام تسجيل الدخول عبر حساب جوجل. يرجى المحاولة مرة أخرى.');
      }
    }
  }, [refreshProfile]);

  const logout = useCallback(async () => {
    tokenRef.current = null;
    await signOut(auth);
    setProfile(null);
    setOwnedCars([]);
    setMyBookings([]);
    setMyEmergencies([]);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        ownedCars,
        myBookings,
        myEmergencies,
        loading,
        authError,
        signInWithGoogle,
        logout,
        refreshProfile,
        authFetch,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
