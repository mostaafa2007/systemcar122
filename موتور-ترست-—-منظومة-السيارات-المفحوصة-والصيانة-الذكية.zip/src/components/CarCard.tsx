import { BatteryCharging, CheckCircle2, Gauge, ShieldCheck, Wrench } from 'lucide-react';
import { CATEGORY_META } from '../data/inspectionCatalog';
import { CarListingDTO } from '../types';
import { SafeImage } from './SafeImage';

interface CarCardProps {
  car: CarListingDTO;
  onSelect: (car: CarListingDTO) => void;
}

export function CarCard({ car, onSelect }: CarCardProps) {
  const score = car.latestInspection?.overallScore;
  const categoryLabel = CATEGORY_META[car.category]?.shortLabel || car.category;

  return (
    <article
      onClick={() => onSelect(car)}
      className="group cursor-pointer flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden transition-transform duration-200 hover:-translate-y-0.5 hover:border-[#1E40AF]/40 dark:hover:border-blue-500/40"
    >
      <div className="relative aspect-[4/3] w-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
        <SafeImage
          src={car.imageUrl}
          alt={`${car.brand} ${car.model} ${car.year}`}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-slate-950/75 via-slate-950/25 to-transparent pointer-events-none" />
        <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-xs text-white">
          <span className="font-medium flex items-center gap-1.5">
            {car.isVerified && score ? (
              <>
                <ShieldCheck className="w-4 h-4 text-[#F59E0B] shrink-0" />
                <span className="tabular-nums">فحص فني معتمد {score}%</span>
              </>
            ) : (
              <span>بانتظار الفحص الفني</span>
            )}
          </span>
          <span className="tabular-nums opacity-90">{car.city}</span>
        </div>
      </div>

      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>{categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{car.year}</span>
            <span aria-hidden="true">·</span>
            <span>{car.transmission}</span>
          </div>

          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-50 leading-snug group-hover:text-[#1E40AF] dark:group-hover:text-blue-400 transition-colors">
            {car.brand} {car.model}
          </h3>

          <div className="pt-1 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-600 dark:text-slate-300">
            <span className="inline-flex items-center gap-1 tabular-nums">
              <Gauge className="w-3.5 h-3.5 text-slate-400" />
              {car.mileage.toLocaleString('ar-EG')} كم
            </span>
            <span className="inline-flex items-center gap-1 tabular-nums">
              <Wrench className="w-3.5 h-3.5 text-slate-400" />
              {car.verifiedServiceCount} صيانة موثقة
            </span>
            {car.batteryCapacityKwh && car.rangeKm && (
              <span className="inline-flex items-center gap-1 text-[#1E40AF] dark:text-blue-400 font-medium tabular-nums">
                <BatteryCharging className="w-3.5 h-3.5" />
                {car.batteryCapacityKwh} kWh · {car.rangeKm} كم
              </span>
            )}
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">السعر المطلوب</div>
            <div className="text-lg font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
              {car.price.toLocaleString('ar-EG')} <span className="text-xs font-medium">ج.م</span>
            </div>
          </div>

          <span className="inline-flex items-center gap-1 text-xs font-bold text-slate-700 dark:text-slate-200 group-hover:text-[#F59E0B] transition-colors whitespace-nowrap shrink-0">
            <CheckCircle2 className="w-4 h-4 text-[#F59E0B]" />
            التفاصيل والتقرير
          </span>
        </div>
      </div>
    </article>
  );
}
