import React, { useEffect, useState } from 'react';
import {
  CalendarClock,
  FileCheck2,
  Gauge,
  Search,
  ShieldCheck,
  Wrench,
} from 'lucide-react';
import { CarListingDTO, PassportResponseDTO } from '../types';
import { SafeImage } from './SafeImage';

interface PassportViewProps {
  cars: CarListingDTO[];
  initialVin?: string | null;
}

export function PassportView({ cars, initialVin }: PassportViewProps) {
  const defaultVin = initialVin || cars[0]?.vinNumber || 'WAUZZZ8V9PA018421';
  const [vinInput, setVinInput] = useState(defaultVin);
  const [passport, setPassport] = useState<PassportResponseDTO | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPassport = async (vin: string) => {
    const clean = vin.trim().toUpperCase();
    if (!clean) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/passport/${encodeURIComponent(clean)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'لم يتم العثور على جواز السفر الرقمي.');
      setPassport(data);
    } catch (err: any) {
      setPassport(null);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const target = initialVin || cars[0]?.vinNumber || 'WAUZZZ8V9PA018421';
    setVinInput(target);
    void fetchPassport(target);
  }, [initialVin, cars.length]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    void fetchPassport(vinInput);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header & VIN Search */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
        <div className="space-y-1">
          <div className="text-xs font-bold text-[#1E40AF] dark:text-blue-400">
            سجل إلكتروني موثق وغير قابل للتلاعب (VIN Digital Passport)
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            جواز السفر الرقمي للسيارة وتنبيهات الصيانة الذكية
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            أدخل رقم الشاسيه (VIN) لاستعراض السجل الكامل لجميع الفحوصات والصيانات المعتمدة ومواعيد
            الصيانة القادمة والتراخيص.
          </p>
        </div>

        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={vinInput}
              onChange={(e) => setVinInput(e.target.value)}
              placeholder="أدخل رقم الشاسيه VIN (17 حرفاً ورقماً)..."
              className="w-full pr-10 pl-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-sm uppercase"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-3 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-sm font-bold cursor-pointer whitespace-nowrap"
          >
            {loading ? 'جاري البحث...' : 'استعلام عن السجل'}
          </button>
        </form>

        {/* Quick-select registered VINs */}
        {cars.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-500 dark:text-slate-400 font-medium">سيارات مسجلة:</span>
            {cars.slice(0, 5).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setVinInput(c.vinNumber);
                  void fetchPassport(c.vinNumber);
                }}
                className={`px-3 py-1.5 rounded-lg border font-medium transition-colors cursor-pointer ${
                  passport?.car.vinNumber === c.vinNumber
                    ? 'bg-[#1E40AF] text-white border-[#1E40AF]'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                {c.brand} {c.model} · <span className="font-mono">{c.vinNumber.slice(-6)}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm font-bold">
          {error}
        </div>
      )}

      {passport && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Vehicle Identity + Automatic Predictive Reminders */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
              <div className="aspect-[16/10] bg-slate-100 dark:bg-slate-800">
                <SafeImage
                  src={passport.car.imageUrl}
                  alt={`${passport.car.brand} ${passport.car.model}`}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-5 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-mono font-semibold text-slate-700 dark:text-slate-200">
                    {passport.car.vinNumber}
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold inline-flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4" />
                    سجل موثق
                  </span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {passport.car.brand} {passport.car.model} {passport.car.year}
                </h2>
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <div>
                    <span className="text-slate-500 block">آخر قراءة عداد موثقة</span>
                    <span className="font-extrabold text-slate-900 dark:text-white tabular-nums">
                      {passport.car.mileage.toLocaleString('ar-EG')} كم
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">متوسط الاستهلاك اليومي</span>
                    <span className="font-extrabold text-slate-900 dark:text-white tabular-nums">
                      {passport.car.dailyAvgKm} كم/يوم
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Smart Predictive Reminders */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 font-extrabold text-base text-slate-900 dark:text-white">
                <CalendarClock className="w-5 h-5 text-[#F59E0B]" />
                التذكيرات التلقائية الذكية
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                <div className="py-3 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">
                      الصيانة الدورية القادمة
                    </div>
                    <div className="text-xs text-slate-500">
                      عند {passport.reminders.nextServiceMileage.toLocaleString('ar-EG')} كم (متبقي{' '}
                      {passport.reminders.remainingKm.toLocaleString('ar-EG')} كم)
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                      خلال {passport.reminders.estimatedServiceDays} يوماً
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      {passport.reminders.estimatedServiceDate}
                    </div>
                  </div>
                </div>

                <div className="py-3 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">تجديد رخصة التسيير</div>
                    <div className="text-xs text-slate-500">تذكير قبل الانتهاء بـ 30 يوماً</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                    {passport.reminders.licenseExpiry || '2027-06-15'}
                  </span>
                </div>

                <div className="py-3 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">
                      تجديد وثيقة التأمين الشامل
                    </div>
                    <div className="text-xs text-slate-500">مرتبط برقم الشاسيه</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                    {passport.reminders.insuranceExpiry || '2027-03-20'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Immutable Timeline */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-[#1E40AF] dark:text-blue-400" />
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  السجل التاريخي غير القابل للتلاعب ({passport.history.length} عملية موثقة)
                </h3>
              </div>
            </div>

            {passport.history.length === 0 ? (
              <p className="text-sm text-slate-500 py-8 text-center">
                لا توجد عمليات صيانة مسجلة بعد لهذا الرقم. بمجرد إتمام أي فحص أو صيانة عبر المنصة
                سيظهر السجل هنا تلقائياً.
              </p>
            ) : (
              <ol className="space-y-4">
                {passport.history.map((entry) => (
                  <li
                    key={entry.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 space-y-2"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-bold text-[#1E40AF] dark:text-blue-400 inline-flex items-center gap-1.5">
                        <Wrench className="w-3.5 h-3.5" />
                        {entry.verifiedByProvider}
                      </span>
                      <span className="tabular-nums font-mono">
                        {new Date(entry.serviceDate).toLocaleDateString('ar-EG')}
                      </span>
                    </div>

                    <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                      {entry.description}
                    </div>

                    {entry.partsReplaced && (
                      <div className="text-xs text-slate-600 dark:text-slate-300">
                        القطع والأعمال الموثقة: {entry.partsReplaced}
                      </div>
                    )}

                    <div className="pt-1 flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                      <span className="inline-flex items-center gap-1 tabular-nums">
                        <Gauge className="w-3.5 h-3.5" />
                        العداد عند الخدمة: {entry.mileageAtService.toLocaleString('ar-EG')} كم
                      </span>
                      <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                        معتمد ومختوم إلكترونياً
                      </span>
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
