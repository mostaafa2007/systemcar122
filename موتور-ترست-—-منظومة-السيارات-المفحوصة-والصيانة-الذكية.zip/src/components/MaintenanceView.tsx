import React, { useState } from 'react';
import {
  AlertTriangle,
  BatteryCharging,
  Building2,
  CheckCircle2,
  Clock,
  Compass,
  MapPin,
  Navigation,
  PhoneCall,
  Truck,
  Wrench,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CarListingDTO, EmergencyRequestDTO } from '../types';

interface MaintenanceViewProps {
  cars: CarListingDTO[];
  initialMode?: 'booking' | 'sos';
}

const SERVICE_PACKAGES = [
  {
    id: 'periodic',
    title: 'صيانة دورية (زيت وفلاتر)',
    description: 'تغيير زيت محرك تخليقي بالكامل، فلتر زيت، فلتر هواء، وفحص 30 نقطة أمان.',
    price: 2850,
    duration: '60 دقيقة',
  },
  {
    id: 'pre_purchase',
    title: 'فحص شامل قبل الشراء (150 نقطة)',
    description: 'فحص موتور، فتيس، شاسيه بالليزر، دهان، وبطارية مع تقرير رقمي معتمد.',
    price: 1650,
    duration: '90 دقيقة',
  },
  {
    id: 'ev_battery',
    title: 'صيانة بطاريات وكهرباء (EV & Hybrid)',
    description: 'فحص توازن خلايا الجهد العالي، دائرة التبريد، الشاحن الداخلي، والبرمجة.',
    price: 3400,
    duration: '75 دقيقة',
  },
  {
    id: 'suspension',
    title: 'عفشة وفرامل وترصيص',
    description: 'تغيير تيل فرامل، فحص طنابير ومساعدين ومقصات، وضبط زوايا بالليزر.',
    price: 2200,
    duration: '80 دقيقة',
  },
];

const CERTIFIED_CENTERS = [
  {
    name: 'مركز النخبة لصيانة السيارات والكهرباء — التجمع الخامس',
    address: 'القاهرة الجديدة — شارع التسعين الشمالي',
    lat: 30.0292,
    lng: 31.4913,
    rating: '4.9',
  },
  {
    name: 'موتور ترست هب — الشيخ زايد (متخصص EV والأوروبي)',
    address: 'الشيخ زايد — المحور المركزي',
    lat: 30.0444,
    lng: 30.9821,
    rating: '4.8',
  },
  {
    name: 'مركز أوتو كير المعتمد — المعادي',
    address: 'المعادي — طريق الأوتوستراد',
    lat: 29.9602,
    lng: 31.2569,
    rating: '4.8',
  },
];

const SOS_ISSUES: Array<{
  id: EmergencyRequestDTO['issueType'];
  label: string;
  eta: string;
}> = [
  { id: 'tow_truck', label: 'ونش إنقاذ هيدروليك', eta: '14 دقيقة' },
  { id: 'battery', label: 'شحن / تغيير بطارية فوري', eta: '11 دقيقة' },
  { id: 'tire', label: 'تغيير أو لحام إطارات', eta: '12 دقيقة' },
  { id: 'fuel', label: 'توصيل وقود طارئ', eta: '10 دقائق' },
  { id: 'electrical', label: 'عطل كهرباء أو كمبيوتر', eta: '16 دقيقة' },
];

export function MaintenanceView({ cars, initialMode = 'booking' }: MaintenanceViewProps) {
  const { firebaseUser, myBookings, myEmergencies, signInWithGoogle, authFetch, refreshProfile } =
    useAuth();

  const [mode, setMode] = useState<'booking' | 'sos'>(initialMode);
  const [locationType, setLocationType] = useState<'mobile_gps' | 'service_center'>('mobile_gps');
  const [selectedPkg, setSelectedPkg] = useState(SERVICE_PACKAGES[0]);
  const [selectedCarId, setSelectedCarId] = useState<number>(cars[0]?.id ?? 1);
  const [selectedCenterIdx, setSelectedCenterIdx] = useState(0);
  const [addressText, setAddressText] = useState('القاهرة الجديدة — التجمع الخامس، الحي الثالث');
  const [coords, setCoords] = useState({ lat: 30.0292, lng: 31.4913 });
  const [scheduledDate, setScheduledDate] = useState(() => {
    const tomorrow = new Date(Date.now() + 86400000);
    return tomorrow.toISOString().slice(0, 16);
  });
  const [locating, setLocating] = useState(false);
  const [bookingBusy, setBookingBusy] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // SOS State
  const [sosIssue, setSosIssue] = useState<EmergencyRequestDTO['issueType']>('tow_truck');
  const [sosAddress, setSosAddress] = useState('طريق السويس الصحراوي — قبل بوابات الرحاب');
  const [sosBusy, setSosBusy] = useState(false);
  const [activeSos, setActiveSos] = useState<EmergencyRequestDTO | null>(
    myEmergencies[0] ?? null
  );

  const detectGps = () => {
    if (!navigator.geolocation) {
      setErrorMsg('المتصفح لا يدعم تحديد الموقع تلقائياً، يمكنك كتابة العنوان يدوياً.');
      return;
    }
    setLocating(true);
    setErrorMsg(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));
        setCoords({ lat, lng });
        setAddressText(`موقع GPS الحالي (${lat}, ${lng})`);
        setSosAddress(`إحداثيات GPS المباشرة (${lat}, ${lng})`);
        setLocating(false);
      },
      () => {
        setLocating(false);
        setErrorMsg('تعذر الوصول إلى GPS، تم اعتماد الموقع الافتراضي ويمكنك تعديله.');
      },
      { timeout: 6000 }
    );
  };

  const handleBookMaintenance = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setFeedback(null);

    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    const carIdToUse = selectedCarId || cars[0]?.id;
    if (!carIdToUse) {
      setErrorMsg('يرجى اختيار سيارة أولاً.');
      return;
    }

    setBookingBusy(true);
    try {
      const center = CERTIFIED_CENTERS[selectedCenterIdx];
      const res = await authFetch('/api/maintenance/bookings', {
        method: 'POST',
        body: JSON.stringify({
          carId: Number(carIdToUse),
          serviceType: selectedPkg.title,
          locationType,
          providerName:
            locationType === 'mobile_gps'
              ? 'فريق موتور ترست للصيانة المتنقلة GPS'
              : center.name,
          addressText: locationType === 'mobile_gps' ? addressText : center.address,
          lat: locationType === 'mobile_gps' ? coords.lat : center.lat,
          lng: locationType === 'mobile_gps' ? coords.lng : center.lng,
          scheduledAt: new Date(scheduledDate).toISOString(),
          totalCost: selectedPkg.price,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تأكيد الحجز.');

      setFeedback('تم تأكيد حجز الصيانة بنجاح وسيُضاف تلقائياً إلى جواز سفر السيارة بعد التنفيذ.');
      await refreshProfile();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setBookingBusy(false);
    }
  };

  const handleTriggerSos = async () => {
    setErrorMsg(null);
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setSosBusy(true);
    try {
      const res = await authFetch('/api/emergency', {
        method: 'POST',
        body: JSON.stringify({
          carId: selectedCarId || cars[0]?.id || null,
          issueType: sosIssue,
          lat: coords.lat,
          lng: coords.lng,
          addressText: sosAddress,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر إرسال بلاغ الطوارئ.');
      setActiveSos(data.emergency);
      await refreshProfile();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setSosBusy(false);
    }
  };

  const latestEmergency = activeSos || myEmergencies[0] || null;

  return (
    <div className="space-y-8 pb-12">
      {/* Mode Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            منظومة الصيانة المتكاملة وطوارئ الطريق
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            اختر صيانة متنقلة تصل لموقعك عبر GPS أو احجز في أقرب مركز معتمد، أو اطلب ونش إنقاذ فوري.
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl self-start">
          <button
            type="button"
            onClick={() => setMode('booking')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              mode === 'booking'
                ? 'bg-[#1E40AF] text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Wrench className="w-4 h-4" />
            حجز صيانة ذكية
          </button>
          <button
            type="button"
            onClick={() => setMode('sos')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              mode === 'sos'
                ? 'bg-red-600 text-white'
                : 'text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            طوارئ الطريق (SOS / ونش)
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm font-bold">
          {errorMsg}
        </div>
      )}
      {feedback && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-sm font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          {feedback}
        </div>
      )}

      {mode === 'booking' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Booking Form */}
          <form
            onSubmit={handleBookMaintenance}
            className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-6"
          >
            {/* Location Mode */}
            <div className="space-y-2.5">
              <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                1. طريقة تقديم الخدمة
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setLocationType('mobile_gps')}
                  className={`p-4 rounded-xl border text-right transition-colors cursor-pointer space-y-1 ${
                    locationType === 'mobile_gps'
                      ? 'border-[#1E40AF] bg-blue-50/60 dark:bg-blue-950/30'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
                    <Navigation className="w-4 h-4 text-[#1E40AF] dark:text-blue-400" />
                    صيانة متنقلة لموقعك (GPS)
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    ورشة مجهزة تصل إلى منزلك أو عملك مباشرة
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setLocationType('service_center')}
                  className={`p-4 rounded-xl border text-right transition-colors cursor-pointer space-y-1 ${
                    locationType === 'service_center'
                      ? 'border-[#1E40AF] bg-blue-50/60 dark:bg-blue-950/30'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
                    <Building2 className="w-4 h-4 text-[#F59E0B]" />
                    مركز صيانة معتمد
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    أقرب مركز معتمد بضمان قطع الغيار الأصلية
                  </div>
                </button>
              </div>
            </div>

            {/* Maintenance Packages */}
            <div className="space-y-2.5">
              <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                2. اختر باقة الصيانة
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SERVICE_PACKAGES.map((pkg) => {
                  const active = selectedPkg.id === pkg.id;
                  return (
                    <button
                      key={pkg.id}
                      type="button"
                      onClick={() => setSelectedPkg(pkg)}
                      className={`p-4 rounded-xl border text-right transition-colors cursor-pointer flex flex-col justify-between gap-2 ${
                        active
                          ? 'border-[#1E40AF] bg-blue-50/60 dark:bg-blue-950/30'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-sm text-slate-900 dark:text-white">
                          {pkg.title}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                          {pkg.description}
                        </p>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                        <span className="font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                          {pkg.price.toLocaleString('ar-EG')} ج.م
                        </span>
                        <span className="text-slate-500 inline-flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {pkg.duration}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Car, Location & Schedule */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <label className="space-y-1">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  السيارة المسجلة
                </span>
                <select
                  value={selectedCarId}
                  onChange={(e) => setSelectedCarId(Number(e.target.value))}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                >
                  {cars.map((car) => (
                    <option key={car.id} value={car.id}>
                      {car.brand} {car.model} {car.year} ({car.vinNumber.slice(-6)})
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  موعد الصيانة
                </span>
                <input
                  type="datetime-local"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  required
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 tabular-nums"
                />
              </label>

              {locationType === 'mobile_gps' ? (
                <div className="sm:col-span-2 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      موقع الصيانة المتنقلة (GPS)
                    </span>
                    <button
                      type="button"
                      onClick={detectGps}
                      className="text-xs font-bold text-[#1E40AF] dark:text-blue-400 inline-flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      {locating ? 'جاري تحديد موقعك...' : 'تحديد موقعي تلقائياً عبر GPS'}
                    </button>
                  </div>
                  <input
                    type="text"
                    value={addressText}
                    onChange={(e) => setAddressText(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                  />
                </div>
              ) : (
                <div className="sm:col-span-2 space-y-1.5">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    اختر المركز المعتمد
                  </span>
                  <select
                    value={selectedCenterIdx}
                    onChange={(e) => setSelectedCenterIdx(Number(e.target.value))}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                  >
                    {CERTIFIED_CENTERS.map((center, idx) => (
                      <option key={center.name} value={idx}>
                        {center.name} — تقييم {center.rating}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs text-slate-500">التكلفة التقديرية الشاملة</div>
                <div className="text-xl font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                  {selectedPkg.price.toLocaleString('ar-EG')} ج.م
                </div>
              </div>

              <button
                type="submit"
                disabled={bookingBusy}
                className="px-6 py-3 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-60"
              >
                {!firebaseUser
                  ? 'سجّل الدخول لتأكيد الحجز'
                  : bookingBusy
                    ? 'جاري التأكيد...'
                    : 'تأكيد حجز الصيانة'}
              </button>
            </div>
          </form>

          {/* Bookings List & Quick SOS Card */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-slate-900 text-white rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2 text-[#F59E0B] font-extrabold text-sm">
                <AlertTriangle className="w-5 h-5" />
                هل تعطلت سيارتك على الطريق الآن؟
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                أرسل طلب إنقاذ فوري بضغطة زر لتحديد موقعك عبر GPS وإرسال أقرب ونش هيدروليك أو فني
                بطاريات وإطارات مع تتبع مباشر.
              </p>
              <button
                type="button"
                onClick={() => setMode('sos')}
                className="w-full py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-slate-950 text-sm font-extrabold cursor-pointer"
              >
                فتح طوارئ الطريق الآن (SOS)
              </button>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                حجوزات الصيانة الخاصة بك ({myBookings.length})
              </h3>

              {myBookings.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 py-4">
                  {firebaseUser
                    ? 'لا توجد حجوزات صيانة مسجلة بعد. احجز أول صيانة وسيُضاف سجلها تلقائياً إلى جواز السفر الرقمي.'
                    : 'سجّل الدخول لعرض ومتابعة حجوزات الصيانة الخاصة بك.'}
                </p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {myBookings.slice(0, 5).map((b) => (
                    <div key={b.id} className="py-3 space-y-1 text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {b.serviceType}
                        </span>
                        <span className="font-bold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                          {b.totalCost.toLocaleString('ar-EG')} ج.م
                        </span>
                      </div>
                      <div className="text-slate-500 dark:text-slate-400">
                        {b.carTitle} · {b.providerName}
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span className="tabular-nums">
                          {new Date(b.scheduledAt).toLocaleDateString('ar-EG')}
                        </span>
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          الحالة:{' '}
                          {b.status === 'completed'
                            ? 'مكتمل وموثق بالـ VIN'
                            : b.status === 'in_progress'
                              ? 'قيد التنفيذ'
                              : b.status === 'confirmed'
                                ? 'مؤكد'
                                : 'بانتظار التأكيد'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* SOS Road Emergency & Live Map Tracker */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-red-600 dark:text-red-400">
                <AlertTriangle className="w-4 h-4" />
                استجابة طوارئ على مدار 24 ساعة
              </div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                طلب ونش إنقاذ أو فني طريق فوري
              </h2>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                حدد نوع العطل
              </span>
              <div className="grid grid-cols-1 gap-2">
                {SOS_ISSUES.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSosIssue(item.id)}
                    className={`px-4 py-3 rounded-xl border text-right flex items-center justify-between text-xs font-bold transition-colors cursor-pointer ${
                      sosIssue === item.id
                        ? 'border-red-600 bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-300'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span className="inline-flex items-center gap-2">
                      {item.id === 'battery' ? (
                        <BatteryCharging className="w-4 h-4" />
                      ) : (
                        <Truck className="w-4 h-4" />
                      )}
                      {item.label}
                    </span>
                    <span className="tabular-nums opacity-75">وصول ~ {item.eta}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-600 dark:text-slate-300">موقعك الحالي</span>
                <button
                  type="button"
                  onClick={detectGps}
                  className="font-bold text-[#1E40AF] dark:text-blue-400 inline-flex items-center gap-1 cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  {locating ? 'جاري التحديد...' : 'تحديث عبر GPS'}
                </button>
              </div>
              <input
                type="text"
                value={sosAddress}
                onChange={(e) => setSosAddress(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm"
              />
              <div className="text-[11px] text-slate-500 font-mono">
                GPS: {coords.lat}, {coords.lng}
              </div>
            </div>

            <button
              type="button"
              onClick={handleTriggerSos}
              disabled={sosBusy}
              className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-extrabold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-60"
            >
              <PhoneCall className="w-4 h-4" />
              {!firebaseUser
                ? 'سجّل الدخول لإرسال طلب الطوارئ'
                : sosBusy
                  ? 'جاري توجيه أقرب وحدة إنقاذ...'
                  : 'إرسال طلب إنقاذ فوري (SOS)'}
            </button>
          </div>

          {/* Live Rescue Tracking Map */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col justify-between gap-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  خريطة التتبع المباشر لوحدة الإنقاذ
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  تغطية الطرق السريعة والمدن الرئيسية مع تحديد المسار الأقصر
                </p>
              </div>
              {latestEmergency && (
                <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                  وقت الوصول المتوقع: {latestEmergency.etaMinutes} دقيقة
                </span>
              )}
            </div>

            {/* Interactive SVG Tactical Road Map */}
            <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 min-h-[280px]">
              <svg
                viewBox="0 0 640 340"
                className="w-full h-full block"
                role="img"
                aria-label="خريطة تتبع وحدة الإنقاذ وموقع السيارة"
              >
                <defs>
                  <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
                    <path
                      d="M 32 0 L 0 0 0 32"
                      fill="none"
                      stroke="rgba(148,163,184,0.12)"
                      strokeWidth="1"
                    />
                  </pattern>
                </defs>
                <rect width="640" height="340" fill="#0F172A" />
                <rect width="640" height="340" fill="url(#grid)" />

                {/* Major road arteries */}
                <path
                  d="M 0 250 Q 200 220 340 165 T 640 85"
                  fill="none"
                  stroke="#334155"
                  strokeWidth="12"
                  strokeLinecap="round"
                />
                <path
                  d="M 90 0 L 240 340"
                  fill="none"
                  stroke="#1E293B"
                  strokeWidth="8"
                />
                <path
                  d="M 420 0 L 520 340"
                  fill="none"
                  stroke="#1E293B"
                  strokeWidth="8"
                />

                {/* Active Rescue Route */}
                <path
                  d="M 150 228 Q 260 202 340 165 T 490 120"
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="4"
                  strokeDasharray="10 6"
                />

                {/* Rescue Truck Marker */}
                <g transform="translate(150, 228)">
                  <circle r="18" fill="rgba(245,158,11,0.22)" />
                  <circle r="9" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="2.5" />
                  <text
                    x="0"
                    y="-24"
                    textAnchor="middle"
                    fill="#FDE68A"
                    fontSize="12"
                    fontWeight="bold"
                  >
                    وحدة الإنقاذ المتجهة إليك
                  </text>
                </g>

                {/* User GPS Pin */}
                <g transform="translate(490, 120)">
                  <circle r="22" fill="rgba(30,64,175,0.35)" />
                  <circle r="10" fill="#1E40AF" stroke="#FFFFFF" strokeWidth="2.5" />
                  <text
                    x="0"
                    y="-26"
                    textAnchor="middle"
                    fill="#FFFFFF"
                    fontSize="12"
                    fontWeight="bold"
                  >
                    موقع سيارتك (GPS)
                  </text>
                </g>
              </svg>
            </div>

            {latestEmergency ? (
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <span className="text-slate-500 block">الفني / السائق المكلف</span>
                  <span className="font-extrabold text-slate-900 dark:text-white">
                    {latestEmergency.driverName}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">العنوان المسجل</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {latestEmergency.addressText}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">حالة البلاغ</span>
                  <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
                    {latestEmergency.status === 'dispatched'
                      ? 'تم توجيه الوحدة'
                      : latestEmergency.status === 'en_route'
                        ? 'الوحدة في الطريق إليك'
                        : latestEmergency.status === 'arrived'
                          ? 'وصلت الوحدة لموقعك'
                          : 'تم إنهاء البلاغ بنجاح'}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-500 dark:text-slate-400">
                بمجرد إرسال طلب الطوارئ سيظهر اسم الكابتن، رقم الونش، وتحديثات المسار المباشر هنا.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
