import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  ClipboardCheck,
  Database,
  Layers,
  LogIn,
  LogOut,
  Moon,
  Shield,
  Sun,
  User,
  Wallet,
  Wrench,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  AdminOverviewDTO,
  CarListingDTO,
  EmergencyRequestDTO,
  MaintenanceBookingDTO,
  UserRole,
} from '../types';
import { InspectionFormView } from './InspectionFormView';

export type AccountSubTab = 'profile' | 'inspector' | 'provider' | 'admin' | 'architecture';

interface AccountWorkspaceViewProps {
  cars: CarListingDTO[];
  initialSubTab?: AccountSubTab;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onRefreshAll: () => Promise<void>;
}

const ROLE_LABELS: Record<UserRole, string> = {
  user: 'مستخدم (مشتري / بائع / مالك)',
  inspector: 'مهندس فحص فني معتمد',
  provider: 'مركز صيانة / فني متنقل',
  admin: 'مدير النظام (Super Admin)',
};

export function AccountWorkspaceView({
  cars,
  initialSubTab = 'profile',
  darkMode,
  onToggleDarkMode,
  onRefreshAll,
}: AccountWorkspaceViewProps) {
  const {
    firebaseUser,
    profile,
    ownedCars,
    myBookings,
    myEmergencies,
    authError,
    signInWithGoogle,
    logout,
    refreshProfile,
    authFetch,
  } = useAuth();

  const [subTab, setSubTab] = useState<AccountSubTab>(initialSubTab);

  // Profile editor state
  const [editName, setEditName] = useState(profile?.name || '');
  const [editPhone, setEditPhone] = useState(profile?.phone || '');
  const [profileSaved, setProfileSaved] = useState<string | null>(null);

  // Provider completion form state
  const [providerMsg, setProviderMsg] = useState<string | null>(null);
  const [partsByBooking, setPartsByBooking] = useState<Record<number, string>>({});
  const [costByBooking, setCostByBooking] = useState<Record<number, number>>({});
  const [mileageByBooking, setMileageByBooking] = useState<Record<number, number>>({});

  // Admin overview state
  const [adminData, setAdminData] = useState<AdminOverviewDTO | null>(null);
  const [adminError, setAdminError] = useState<string | null>(null);
  const [adminBusy, setAdminBusy] = useState(false);

  useEffect(() => {
    setSubTab(initialSubTab);
  }, [initialSubTab]);

  useEffect(() => {
    if (profile) {
      setEditName(profile.name);
      setEditPhone(profile.phone);
    }
  }, [profile]);

  const loadAdminOverview = async () => {
    if (!firebaseUser || profile?.role !== 'admin') return;
    setAdminBusy(true);
    setAdminError(null);
    try {
      const res = await authFetch('/api/admin/overview');
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تحميل بيانات الإدارة.');
      setAdminData(data);
    } catch (err: any) {
      setAdminError(err.message);
    } finally {
      setAdminBusy(false);
    }
  };

  useEffect(() => {
    if (subTab === 'admin' && profile?.role === 'admin') {
      void loadAdminOverview();
    }
  }, [subTab, profile?.role]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaved(null);
    const res = await authFetch('/api/me/profile', {
      method: 'PATCH',
      body: JSON.stringify({ name: editName, phone: editPhone }),
    });
    if (res.ok) {
      setProfileSaved('تم تحديث بيانات ملفك الشخصي بنجاح.');
      await refreshProfile();
    }
  };

  const handleUpdateBooking = async (
    booking: MaintenanceBookingDTO,
    nextStatus: MaintenanceBookingDTO['status']
  ) => {
    setProviderMsg(null);
    const res = await authFetch(`/api/maintenance/bookings/${booking.id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        status: nextStatus,
        totalCost: costByBooking[booking.id] ?? booking.totalCost,
        partsReplaced:
          partsByBooking[booking.id] || 'تغيير زيت وفلاتر أصلية وفحص شامل للأنظمة',
        mileageAtService: mileageByBooking[booking.id] || undefined,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setProviderMsg(data.error || 'تعذر تحديث الطلب.');
      return;
    }
    setProviderMsg(
      nextStatus === 'completed'
        ? 'تم إتمام الصيانة وإضافة الفاتورة وقطع الغيار تلقائياً إلى جواز السفر الرقمي (VIN).'
        : 'تم تحديث حالة حجز الصيانة بنجاح.'
    );
    await refreshProfile();
    await onRefreshAll();
  };

  const handleUpdateEmergency = async (
    em: EmergencyRequestDTO,
    status: EmergencyRequestDTO['status']
  ) => {
    const res = await authFetch(`/api/emergency/${em.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      setProviderMsg('تم تحديث حالة وحدة الإنقاذ بنجاح.');
      await refreshProfile();
    }
  };

  const handleAdminRoleChange = async (userId: number, role: UserRole) => {
    const res = await authFetch(`/api/admin/users/${userId}/role`, {
      method: 'PATCH',
      body: JSON.stringify({ role }),
    });
    if (res.ok) {
      await loadAdminOverview();
      await refreshProfile();
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Account & Theme Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#1E40AF] text-white flex items-center justify-center font-extrabold text-lg shrink-0">
            {profile ? profile.name.slice(0, 1) : <User className="w-5 h-5" />}
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
              {profile ? profile.name : 'حسابي وبوابات الصلاحيات'}
            </h1>
            <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-2 mt-0.5">
              {profile ? (
                <>
                  <span>{ROLE_LABELS[profile.role]}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{profile.email}</span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 font-bold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                    <Wallet className="w-3.5 h-3.5" />
                    الرصيد: {profile.walletBalance.toLocaleString('ar-EG')} ج.م
                  </span>
                </>
              ) : (
                <span>سجّل الدخول بحساب جوجل لإدارة سياراتك، الحجوزات، وبوابات العمل</span>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onToggleDarkMode}
            className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            {darkMode ? <Sun className="w-4 h-4 text-[#F59E0B]" /> : <Moon className="w-4 h-4 text-[#1E40AF]" />}
            {darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
          </button>

          {firebaseUser ? (
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </button>
          ) : (
            <button
              type="button"
              onClick={signInWithGoogle}
              className="px-5 py-2 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <LogIn className="w-4 h-4" />
              تسجيل الدخول بحساب جوجل
            </button>
          )}
        </div>
      </div>

      {authError && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs font-bold">
          {authError}
        </div>
      )}

      {/* Role Workspace Switcher */}
      <div className="flex items-center gap-1.5 p-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
        {[
          { id: 'profile', label: 'ملفي وسياراتي', icon: User },
          { id: 'inspector', label: 'نموذج الفحص 150 نقطة', icon: ClipboardCheck },
          { id: 'provider', label: 'بوابة مركز الصيانة والفني', icon: Wrench },
          { id: 'admin', label: 'لوحة مدير النظام (Admin)', icon: Shield },
          { id: 'architecture', label: 'هيكلية النظام وقاعدة البيانات', icon: Layers },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = subTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubTab(tab.id as AccountSubTab)}
              className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                active
                  ? 'bg-[#1E40AF] text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 1. User Profile Tab */}
      {subTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              تحديث بيانات الحساب
            </h2>
            {!firebaseUser ? (
              <div className="space-y-3 py-4">
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  سجّل الدخول لمتابعة سياراتك المعروضة للبيع وحجوزات الصيانة ورصيد محفظتك.
                </p>
                <button
                  type="button"
                  onClick={signInWithGoogle}
                  className="px-5 py-2.5 rounded-xl bg-[#1E40AF] text-white text-xs font-bold cursor-pointer"
                >
                  تسجيل الدخول الآن
                </button>
              </div>
            ) : (
              <form onSubmit={handleSaveProfile} className="space-y-4 text-sm">
                {profileSaved && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    {profileSaved}
                  </div>
                )}
                <label className="space-y-1 block">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">الاسم</span>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                  />
                </label>
                <label className="space-y-1 block">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    رقم الهاتف للتواصل والطوارئ
                  </span>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="010xxxxxxxx"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono"
                  />
                </label>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#1E40AF] text-white text-xs font-bold cursor-pointer"
                >
                  حفظ التعديلات
                </button>
              </form>
            )}
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              سياراتي المسجلة ({ownedCars.length})
            </h2>
            {ownedCars.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-6">
                لم تقم بإضافة سيارات بعد. يمكنك إضافة سيارتك من صفحة السوق مع التسعير الذكي وحجز فحص
                150 نقطة.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {ownedCars.map((c) => (
                  <div key={c.id} className="py-3 flex items-center justify-between gap-4 text-sm">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">
                        {c.brand} {c.model} {c.year}
                      </div>
                      <div className="text-xs text-slate-500 font-mono">VIN: {c.vinNumber}</div>
                    </div>
                    <div className="text-left">
                      <div className="font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                        {c.price.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                        {c.isVerified ? 'مفحوصة ومعتمدة' : 'بانتظار الفحص الفني'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. Inspector 150-Point Portal */}
      {subTab === 'inspector' && (
        <InspectionFormView cars={cars} onInspectionSubmitted={onRefreshAll} />
      )}

      {/* 3. Service Provider & Road Rescue Portal */}
      {subTab === 'provider' && (
        <div className="space-y-6">
          {providerMsg && (
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-sm font-bold">
              {providerMsg}
            </div>
          )}

          {profile?.role !== 'provider' && profile?.role !== 'admin' ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center space-y-2">
              <p className="font-extrabold text-slate-900 dark:text-white">
                هذه البوابة مخصصة لمراكز الصيانة المعتمدة والفنيين المتنقلين ومدير النظام
              </p>
              <p className="text-xs text-slate-500">
                سجّل الدخول بحساب مركز صيانة معتمد أو حساب المدير لإدارة الحجوزات وإصدار الفواتير
                الموثقة في سجل VIN.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  طلبات الصيانة الواردة ({myBookings.length})
                </h2>
                {myBookings.length === 0 ? (
                  <p className="text-xs text-slate-500 py-6">لا توجد حجوزات صيانة حالياً.</p>
                ) : (
                  <div className="space-y-4">
                    {myBookings.map((b) => (
                      <div
                        key={b.id}
                        className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3 text-xs"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                            #{b.id} — {b.serviceType}
                          </span>
                          <span className="font-bold text-[#1E40AF] dark:text-blue-400">
                            {b.locationType === 'mobile_gps' ? 'صيانة متنقلة GPS' : 'مركز صيانة'}
                          </span>
                        </div>
                        <div className="text-slate-600 dark:text-slate-300">
                          السيارة: {b.carTitle} · العميل: {b.customerName} · العنوان: {b.addressText}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <input
                            type="text"
                            placeholder="قطع الغيار المستبدلة..."
                            value={partsByBooking[b.id] ?? ''}
                            onChange={(e) =>
                              setPartsByBooking((p) => ({ ...p, [b.id]: e.target.value }))
                            }
                            className="px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700"
                          />
                          <input
                            type="number"
                            placeholder="التكلفة النهائية (ج.م)"
                            value={costByBooking[b.id] ?? b.totalCost}
                            onChange={(e) =>
                              setCostByBooking((p) => ({ ...p, [b.id]: Number(e.target.value) }))
                            }
                            className="px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 tabular-nums"
                          />
                          <input
                            type="number"
                            placeholder="العداد الحالي (كم)"
                            value={mileageByBooking[b.id] ?? ''}
                            onChange={(e) =>
                              setMileageByBooking((p) => ({ ...p, [b.id]: Number(e.target.value) }))
                            }
                            className="px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 tabular-nums"
                          />
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleUpdateBooking(b, 'confirmed')}
                            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 font-bold cursor-pointer"
                          >
                            تأكيد الموعد
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateBooking(b, 'in_progress')}
                            className="px-3 py-1.5 rounded-lg bg-[#F59E0B] text-slate-950 font-bold cursor-pointer"
                          >
                            بدء التنفيذ
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateBooking(b, 'completed')}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
                          >
                            إتمام وتوثيق في سجل VIN
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  بلاغات طوارئ الطريق النشطة ({myEmergencies.length})
                </h2>
                {myEmergencies.length === 0 ? (
                  <p className="text-xs text-slate-500 py-6">لا توجد بلاغات طوارئ حالياً.</p>
                ) : (
                  <div className="space-y-3">
                    {myEmergencies.map((em) => (
                      <div
                        key={em.id}
                        className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 text-xs"
                      >
                        <div className="flex justify-between font-bold">
                          <span>بلاغ #{em.id} — {em.customerName}</span>
                          <span className="text-red-600 dark:text-red-400">{em.status}</span>
                        </div>
                        <div className="text-slate-500">{em.addressText}</div>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {(['en_route', 'arrived', 'resolved'] as EmergencyRequestDTO['status'][]).map(
                            (st) => (
                              <button
                                key={st}
                                type="button"
                                onClick={() => handleUpdateEmergency(em, st)}
                                className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                              >
                                {st === 'en_route'
                                  ? 'في الطريق'
                                  : st === 'arrived'
                                    ? 'وصل الموقع'
                                    : 'تم الإنقاذ'}
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. Super Admin Dashboard */}
      {subTab === 'admin' && (
        <div className="space-y-6">
          {profile?.role !== 'admin' ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center space-y-2">
              <p className="font-extrabold text-slate-900 dark:text-white">
                لوحة التحكم الشاملة متاحة لمدير النظام (Super Admin) فقط
              </p>
              <p className="text-xs text-slate-500">
                يتم التحقق من صلاحيات المدير على الخادم عبر Firebase Auth وجدول المستخدمين في
                PostgreSQL.
              </p>
            </div>
          ) : adminBusy ? (
            <div className="h-48 rounded-2xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse" />
          ) : adminError ? (
            <div className="p-4 rounded-xl bg-red-50 text-red-700 text-sm font-bold">{adminError}</div>
          ) : adminData ? (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
                  <div className="text-xs text-slate-500">إجمالي المستخدمين</div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums mt-1">
                    {adminData.stats.totalUsers}
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
                  <div className="text-xs text-slate-500">السيارات المفحوصة / الكل</div>
                  <div className="text-2xl font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums mt-1">
                    {adminData.stats.verifiedCars} / {adminData.stats.totalCars}
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
                  <div className="text-xs text-slate-500">حجوزات الصيانة والطوارئ</div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums mt-1">
                    {adminData.stats.totalBookings} · {adminData.stats.activeEmergencies} طوارئ
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
                  <div className="text-xs text-slate-500">تقدير العمولات المستحقة</div>
                  <div className="text-2xl font-extrabold text-[#F59E0B] tabular-nums mt-1">
                    {adminData.stats.estimatedCommissionEgp.toLocaleString('ar-EG')} ج.م
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                    إدارة المستخدمين والاعتمادات والصلاحيات (RBAC)
                  </h2>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="py-3 px-4 font-bold">الاسم</th>
                        <th className="py-3 px-4 font-bold">البريد الإلكتروني</th>
                        <th className="py-3 px-4 font-bold">الصلاحية الحالية</th>
                        <th className="py-3 px-4 font-bold">المحفظة</th>
                        <th className="py-3 px-4 font-bold">تغيير الصلاحية</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {adminData.users.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                          <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                            {u.name}
                          </td>
                          <td className="py-3 px-4 font-mono text-slate-500">{u.email}</td>
                          <td className="py-3 px-4 font-bold text-[#1E40AF] dark:text-blue-400">
                            {ROLE_LABELS[u.role]}
                          </td>
                          <td className="py-3 px-4 tabular-nums">
                            {u.walletBalance.toLocaleString('ar-EG')} ج.م
                          </td>
                          <td className="py-3 px-4">
                            <select
                              value={u.role}
                              onChange={(e) => handleAdminRoleChange(u.id, e.target.value as UserRole)}
                              className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 font-bold"
                            >
                              <option value="user">مستخدم عادي</option>
                              <option value="inspector">مهندس فحص</option>
                              <option value="provider">مركز صيانة</option>
                              <option value="admin">مدير نظام</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : null}
        </div>
      )}

      {/* 5. System Architecture & User Flow Visual Blueprint */}
      {subTab === 'architecture' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-[#1E40AF] dark:text-blue-400" />
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                هيكلية النظام (System Architecture) وتدفق العمليات (User Flow)
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-extrabold text-[#1E40AF] dark:text-blue-400">
                  1. الواجهة الأمامية (React RTL)
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  واجهة عربية RTL بخطوط Cairo وTajawal، محرك التصنيفات الديناميكي (EV / صيني / أوروبي /
                  اقتصادي)، نموذج فحص 150 نقطة، تتبع SOS، وحاسبة التقسيط.
                </p>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-extrabold text-[#F59E0B]">
                  2. بوابة الهوية والصلاحيات (RBAC)
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  Firebase Auth لتوثيق الهوية عبر Bearer Token مع Middleware خادم يتحقق من الأدوار
                  الأربعة: User, Inspector, Provider, Admin.
                </p>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-extrabold text-emerald-600 dark:text-emerald-400">
                  3. واجهات RESTful APIs (Express)
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  مسارات مؤمّنة بـ Zod Validation لسوق السيارات، التسعير الذكي، تقارير الفحص، حجوزات
                  الصيانة، طوارئ SOS، وجواز السفر الرقمي للـ VIN.
                </p>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-extrabold text-slate-900 dark:text-white">
                  4. قاعدة البيانات (PostgreSQL + Drizzle)
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  6 جداول علائقية مترابطة بمفاتيح خارجية: Users, Cars, InspectionReports,
                  MaintenanceBookings, MaintenanceHistory, EmergencyRequests.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <div className="font-extrabold text-slate-900 dark:text-white text-sm">
                تدفق العمليات المتكامل (End-to-End Flow)
              </div>
              <p>
                البائع يضيف سيارته ويستخدم أداة التسعير الذكي ← يطلب فحص 150 نقطة ← مهندس الفحص يستلم
                الطلب ويصدر التقرير ← تُوثَّق السيارة تلقائياً في السوق ويُضاف سجل غير قابل للتلاعب
                بجواز السفر الرقمي (VIN) ← المالك الجديد يحجز صيانة متنقلة أو مركز معتمد ← المركز ينهي
                الصيانة ويدخل الفاتورة وقطع الغيار ← تُضاف تلقائياً إلى سجل VIN وتُحدَّث تذكيرات
                الصيانة القادمة.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
