import {
  AlertTriangle,
  ArrowLeft,
  BatteryCharging,
  ClipboardCheck,
  FileCheck2,
  ShieldCheck,
  Wrench,
} from 'lucide-react';
import { CATEGORY_META } from '../data/inspectionCatalog';
import { CarCategory, CarListingDTO } from '../types';
import { CarCard } from './CarCard';
import { SafeImage } from './SafeImage';

interface HomeViewProps {
  cars: CarListingDTO[];
  loading: boolean;
  activeCategory: CarCategory;
  onCategoryChange: (cat: CarCategory) => void;
  onSelectCar: (car: CarListingDTO) => void;
  onNavigate: (tab: 'home' | 'marketplace' | 'maintenance' | 'passport' | 'account', subAction?: string) => void;
}

const CATEGORIES: CarCategory[] = ['all', 'ev_hybrid', 'chinese', 'european', 'economy'];

export function HomeView({
  cars,
  loading,
  activeCategory,
  onCategoryChange,
  onSelectCar,
  onNavigate,
}: HomeViewProps) {
  const filteredCars =
    activeCategory === 'all'
      ? cars.filter((c) => c.status !== 'personal').slice(0, 6)
      : cars.filter((c) => c.category === activeCategory && c.status !== 'personal').slice(0, 6);

  const verifiedCount = cars.filter((c) => c.isVerified).length;

  return (
    <div className="space-y-12 pb-12">
      {/* Editorial 2-Column Hero */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 lg:p-10">
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-[#1E40AF] dark:text-blue-400">
              <span>فحص فني 150 نقطة</span>
              <span aria-hidden="true">·</span>
              <span>صيانة متنقلة وونش طوارئ</span>
              <span aria-hidden="true">·</span>
              <span>جواز سفر رقمي للسيارة</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-[2.65rem] font-extrabold text-slate-900 dark:text-white leading-[1.22]">
              اشترِ، افحص، وصُن سيارتك بثقة موثقة برقم الشاسيه
            </h1>

            <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
              منظومة سيارات عربية متكاملة تجمع بين سوق السيارات المفحوصة فنياً بـ 150 نقطة، وحجز الصيانة
              المتنقلة أو المراكز المعتمدة، وسجل صيانة إلكتروني غير قابل للتلاعب يرفع قيمة سيارتك عند
              إعادة البيع.
            </p>
          </div>

          <div className="pt-8 space-y-5">
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onNavigate('marketplace')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                تصفح السوق المفحوص
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('maintenance', 'sos')}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-slate-950 text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <AlertTriangle className="w-4 h-4" />
                طوارئ الطريق (SOS / ونش)
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-4">
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                  150 نقطة
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">معيار فحص هندسي</div>
              </div>
              <div>
                <div className="text-xl font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                  {verifiedCount} سيارات
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">موثقة في السوق الآن</div>
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                  14 دقيقة
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">متوسط وصول الإنقاذ</div>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 min-h-[300px] lg:min-h-full bg-slate-900">
          <SafeImage
            src="/src/assets/images/hero_automotive_showroom_1795476301102.jpg"
            alt="استوديو الفحص الفني والعرض للسيارات الكهربائية والحديثة"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-transparent" />
          <div className="absolute bottom-5 inset-x-6 flex flex-col sm:flex-row sm:items-end justify-between gap-3 text-white">
            <div>
              <div className="text-xs text-amber-300 font-medium">محرك التصنيف الذكي</div>
              <div className="text-lg font-bold">
                فحص بطاريات السيارات الكهربائية (SoH) والشاسيه بالليزر
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('passport')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-white/95 hover:text-[#F59E0B] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileCheck2 className="w-4 h-4 text-[#F59E0B]" />
              افحص رقم الشاسيه (VIN)
            </button>
          </div>
        </div>
      </section>

      {/* Dynamic Category Engine */}
      <section className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              سوق السيارات المفحوصة
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              {CATEGORY_META[activeCategory]?.description}
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('marketplace')}
            className="inline-flex items-center gap-1.5 text-sm font-bold text-[#1E40AF] dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
          >
            عرض السوق الكامل والفلاتر المتقدمة
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Interactive Category Switcher */}
        <div
          className="flex items-center gap-1.5 p-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto"
          role="tablist"
          aria-label="تصنيفات السيارات"
        >
          {CATEGORIES.map((cat) => {
            const active = activeCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => onCategoryChange(cat)}
                className={`px-4 py-2.5 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
                  active
                    ? 'bg-[#1E40AF] text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {cat === 'ev_hybrid' && <BatteryCharging className="w-4 h-4" />}
                {CATEGORY_META[cat].shortLabel}
              </button>
            );
          })}
        </div>

        {/* Featured Cars Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-[360px] rounded-xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse"
              />
            ))}
          </div>
        ) : filteredCars.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-3">
            <p className="text-slate-700 dark:text-slate-300 font-bold">
              لا توجد سيارات معروضة في هذا التصنيف حالياً.
            </p>
            <button
              type="button"
              onClick={() => onCategoryChange('all')}
              className="px-4 py-2 rounded-lg bg-[#1E40AF] text-white text-xs font-bold cursor-pointer"
            >
              عرض جميع السيارات
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCars.map((car) => (
              <CarCard key={car.id} car={car} onSelect={onSelectCar} />
            ))}
          </div>
        )}
      </section>

      {/* Claim-to-Proof: 150-Point Technical Inspection & Maintenance Ecosystem */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        <div className="lg:col-span-5 relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 min-h-[260px]">
          <SafeImage
            src="/src/assets/images/car_inspection_bay_1795476300338.jpg"
            alt="مركز الفحص الفني المعتمد 150 نقطة"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <div className="text-xs font-bold text-[#F59E0B]">
              منظومة الصلاحيات المتكاملة (مشتري · مهندس فحص · مركز صيانة · إدارة)
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              تقرير فحص 150 نقطة موثق ومرتبط تلقائياً بجواز سفر السيارة
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              يقوم مهندس الفحص الفني باستلام الطلبات وملء النموذج التفاعلي لـ 150 نقطة تشمل المحرك،
              الفتيس، الشاسيه، الدهان، وصحة البطارية مع إرفاق الصور. وبمجرد الإصدار، يُضاف التقرير فوراً
              إلى السجل التاريخي لرقم الشاسيه (VIN) ولا يمكن التلاعب به.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('account', 'inspector')}
              className="text-right p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-[#1E40AF] dark:hover:border-blue-500 transition-colors space-y-2 cursor-pointer"
            >
              <ClipboardCheck className="w-5 h-5 text-[#1E40AF] dark:text-blue-400" />
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                نموذج الفحص 150 نقطة
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                بوابة مهندس الفحص وإصدار الشهادات
              </div>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('maintenance')}
              className="text-right p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-[#1E40AF] dark:hover:border-blue-500 transition-colors space-y-2 cursor-pointer"
            >
              <Wrench className="w-5 h-5 text-[#F59E0B]" />
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                الصيانة الذكية و GPS
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                صيانة متنقلة لموقعك أو مركز معتمد
              </div>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('passport')}
              className="text-right p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-[#1E40AF] dark:hover:border-blue-500 transition-colors space-y-2 cursor-pointer"
            >
              <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                جواز السفر الرقمي
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                سجل الصيانة وتنبيهات التجديد التلقائية
              </div>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
