import React, { useMemo, useState } from 'react';
import {
  BatteryCharging,
  Calculator,
  CheckCircle2,
  FileCheck2,
  Gauge,
  Plus,
  RotateCw,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Wrench,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CATEGORY_META } from '../data/inspectionCatalog';
import { CarCategory, CarListingDTO, FairPriceEstimateDTO } from '../types';
import { CarCard } from './CarCard';
import { SafeImage } from './SafeImage';

interface MarketplaceViewProps {
  cars: CarListingDTO[];
  loading: boolean;
  activeCategory: CarCategory;
  onCategoryChange: (cat: CarCategory) => void;
  selectedCar: CarListingDTO | null;
  onSelectCar: (car: CarListingDTO | null) => void;
  onOpenPassport: (vin: string) => void;
  onCarsUpdated: () => Promise<void>;
}

const CATEGORIES: CarCategory[] = ['all', 'ev_hybrid', 'chinese', 'european', 'economy'];

const VIEW_ANGLES = [
  { id: 'front', label: 'زاوية أمامية 3/4', rotateY: 0, scale: 1 },
  { id: 'side', label: 'منظور جانبي 90°', rotateY: 14, scale: 1.04 },
  { id: 'rear', label: 'زاوية خلفية 180°', rotateY: -14, scale: 1.03 },
  { id: 'inspection', label: 'منصة الفحص الفني', rotateY: 0, scale: 1.02 },
];

export function MarketplaceView({
  cars,
  loading,
  activeCategory,
  onCategoryChange,
  selectedCar,
  onSelectCar,
  onOpenPassport,
  onCarsUpdated,
}: MarketplaceViewProps) {
  const { firebaseUser, signInWithGoogle, authFetch } = useAuth();

  const [search, setSearch] = useState('');
  const [minBattery, setMinBattery] = useState<number>(0);
  const [minRange, setMinRange] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(0);

  // Add Car Wizard state
  const [showAddWizard, setShowAddWizard] = useState(false);
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3>(1);
  const [formVin, setFormVin] = useState('');
  const [formBrand, setFormBrand] = useState('بي واي دي');
  const [formModel, setFormModel] = useState('Seal Excellence');
  const [formYear, setFormYear] = useState(2024);
  const [formCategory, setFormCategory] = useState<Exclude<CarCategory, 'all'>>('ev_hybrid');
  const [formMileage, setFormMileage] = useState(18000);
  const [formPrice, setFormPrice] = useState(1950000);
  const [formBattery, setFormBattery] = useState(82.5);
  const [formRange, setFormRange] = useState(570);
  const [formCity, setFormCity] = useState('القاهرة الجديدة');
  const [formTransmission, setFormTransmission] = useState('أوتوماتيك كهربائي');
  const [requestInspection, setRequestInspection] = useState(true);
  const [expectedScore, setExpectedScore] = useState(94);
  const [estimate, setEstimate] = useState<FairPriceEstimateDTO | null>(null);
  const [estimating, setEstimating] = useState(false);
  const [submittingCar, setSubmittingCar] = useState(false);
  const [wizardError, setWizardError] = useState<string | null>(null);
  const [wizardSuccess, setWizardSuccess] = useState<string | null>(null);

  // Car detail 360 viewer & installment calculator state
  const [angleIndex, setAngleIndex] = useState(0);
  const [downPaymentPct, setDownPaymentPct] = useState(25);
  const [months, setMonths] = useState(60);
  const [annualRate, setAnnualRate] = useState(14.5);

  const filteredCars = useMemo(() => {
    const q = search.trim().toLowerCase();
    return cars.filter((car) => {
      if (car.status === 'personal') return false;
      if (activeCategory !== 'all' && car.category !== activeCategory) return false;
      if (activeCategory === 'ev_hybrid') {
        if (minBattery > 0 && (!car.batteryCapacityKwh || car.batteryCapacityKwh < minBattery)) {
          return false;
        }
        if (minRange > 0 && (!car.rangeKm || car.rangeKm < minRange)) {
          return false;
        }
      }
      if (maxPrice > 0 && car.price > maxPrice) return false;
      if (q) {
        const hay = `${car.brand} ${car.model} ${car.year} ${car.city} ${car.vinNumber}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [cars, activeCategory, minBattery, minRange, maxPrice, search]);

  const runFairPriceEstimator = async () => {
    setEstimating(true);
    setWizardError(null);
    try {
      const res = await fetch('/api/pricing/estimate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brand: formBrand,
          model: formModel,
          year: Number(formYear),
          category: formCategory,
          mileage: Number(formMileage),
          inspectionScore: Number(expectedScore),
          batteryCapacityKwh: formCategory === 'ev_hybrid' ? Number(formBattery) : null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر حساب السعر العادل.');
      setEstimate(data);
      setFormPrice(data.fairPrice);
    } catch (err: any) {
      setWizardError(err.message);
    } finally {
      setEstimating(false);
    }
  };

  const handlePublishCar = async (e: React.FormEvent) => {
    e.preventDefault();
    setWizardError(null);
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setSubmittingCar(true);
    try {
      const vinToUse =
        formVin.trim().length >= 10
          ? formVin.trim().toUpperCase()
          : `MT${Date.now().toString().slice(-8)}EG2026`;

      const res = await authFetch('/api/cars', {
        method: 'POST',
        body: JSON.stringify({
          vinNumber: vinToUse,
          brand: formBrand,
          model: formModel,
          year: Number(formYear),
          category: formCategory,
          price: Number(formPrice),
          mileage: Number(formMileage),
          requestInspection,
          batteryCapacityKwh: formCategory === 'ev_hybrid' ? Number(formBattery) : null,
          rangeKm: formCategory === 'ev_hybrid' ? Number(formRange) : null,
          transmission: formTransmission,
          fuelType: formCategory === 'ev_hybrid' ? 'كهرباء بالكامل' : 'بنزين',
          city: formCity,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر نشر السيارة.');

      setWizardSuccess(
        requestInspection
          ? 'تم تسجيل السيارة بنجاح وحجز موعد الفحص الفني المعتمد (150 نقطة) لتوثيق الإعلان.'
          : 'تم نشر إعلان سيارتك بنجاح في السوق.'
      );
      await onCarsUpdated();
      setTimeout(() => {
        setShowAddWizard(false);
        setWizardStep(1);
        setWizardSuccess(null);
        setFormVin('');
      }, 1800);
    } catch (err: any) {
      setWizardError(err.message || 'حدث خطأ أثناء الحفظ.');
    } finally {
      setSubmittingCar(false);
    }
  };

  const installmentCalc = useMemo(() => {
    if (!selectedCar) return null;
    const downPayment = Math.round((selectedCar.price * downPaymentPct) / 100);
    const principal = selectedCar.price - downPayment;
    const monthlyRate = annualRate / 100 / 12;
    const monthly =
      monthlyRate === 0
        ? principal / months
        : (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
          (Math.pow(1 + monthlyRate, months) - 1);
    return {
      downPayment,
      principal,
      monthlyPayment: Math.round(monthly),
    };
  }, [selectedCar, downPaymentPct, months, annualRate]);

  return (
    <div className="space-y-8 pb-12">
      {/* Header & Sell CTA */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            سوق السيارات المفحوصة
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            تبديل فوري بين الشمولية والتخصص مع تقارير فحص 150 نقطة وسجل صيانة موثق برقم الشاسيه.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setShowAddWizard(true);
            setWizardStep(1);
            setWizardError(null);
            setWizardSuccess(null);
          }}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-slate-950 text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          أضف سيارتك للبيع + التسعير الذكي
        </button>
      </div>

      {/* Dynamic Category Engine Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
        <div
          className="flex items-center gap-1.5 overflow-x-auto pb-1"
          role="tablist"
          aria-label="محرك التصنيفات الديناميكي"
        >
          {CATEGORIES.map((cat) => {
            const active = activeCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => onCategoryChange(cat)}
                className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
                  active
                    ? 'bg-[#1E40AF] text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {cat === 'ev_hybrid' && <BatteryCharging className="w-4 h-4" />}
                {CATEGORY_META[cat].label}
              </button>
            );
          })}
        </div>

        {/* Search & Price Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث بالماركة، الموديل، المدينة، أو رقم الشاسيه (VIN)..."
              className="w-full pr-10 pl-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-[#1E40AF]"
            />
          </div>

          <div className="md:col-span-4 flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              aria-label="الحد الأقصى للسعر"
              className="w-full px-3 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-[#1E40AF]"
            >
              <option value={0}>جميع الأسعار</option>
              <option value={1500000}>حتى 1,500,000 ج.م</option>
              <option value={2500000}>حتى 2,500,000 ج.م</option>
              <option value={4000000}>حتى 4,000,000 ج.م</option>
              <option value={7500000}>حتى 7,500,000 ج.م</option>
            </select>
          </div>

          <div className="md:col-span-2 flex items-center justify-end text-xs font-medium text-slate-500 dark:text-slate-400 tabular-nums">
            {filteredCars.length} نتيجة متاحة
          </div>
        </div>

        {/* Specialized EV & Hybrid Dynamic Filters */}
        {activeCategory === 'ev_hybrid' && (
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200">
                <span className="inline-flex items-center gap-1.5">
                  <BatteryCharging className="w-4 h-4 text-[#1E40AF] dark:text-blue-400" />
                  الحد الأدنى لسعة البطارية (kWh)
                </span>
                <span className="tabular-nums text-[#1E40AF] dark:text-blue-400">
                  {minBattery > 0 ? `${minBattery} kWh فأكثر` : 'الكل'}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={5}
                value={minBattery}
                onChange={(e) => setMinBattery(Number(e.target.value))}
                className="w-full accent-[#1E40AF]"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200">
                <span className="inline-flex items-center gap-1.5">
                  <Gauge className="w-4 h-4 text-[#F59E0B]" />
                  الحد الأدنى لمدى الشحن (كم)
                </span>
                <span className="tabular-nums text-[#F59E0B]">
                  {minRange > 0 ? `${minRange} كم فأكثر` : 'الكل'}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={650}
                step={50}
                value={minRange}
                onChange={(e) => setMinRange(Number(e.target.value))}
                className="w-full accent-[#F59E0B]"
              />
            </div>
          </div>
        )}
      </div>

      {/* Results Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="h-[360px] rounded-xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse"
            />
          ))}
        </div>
      ) : filteredCars.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center space-y-3">
          <p className="text-base font-bold text-slate-800 dark:text-slate-200">
            لم يتم العثور على سيارات مطابقة للفلاتر الحالية
          </p>
          <button
            type="button"
            onClick={() => {
              onCategoryChange('all');
              setSearch('');
              setMinBattery(0);
              setMinRange(0);
              setMaxPrice(0);
            }}
            className="px-4 py-2 rounded-lg bg-[#1E40AF] text-white text-xs font-bold cursor-pointer"
          >
            إعادة ضبط الفلاتر
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCars.map((car) => (
            <CarCard
              key={car.id}
              car={car}
              onSelect={(c) => {
                setAngleIndex(0);
                onSelectCar(c);
              }}
            />
          ))}
        </div>
      )}

      {/* Car Details Modal with 360 Viewer, Inspection Breakdown, VIN Link & Installment Calculator */}
      {selectedCar && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
          onClick={() => onSelectCar(null)}
        >
          <div
            className="w-full max-w-5xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden my-auto max-h-[92vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 z-10 flex items-center justify-between gap-4 px-5 py-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  VIN: {selectedCar.vinNumber}
                </div>
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                  {selectedCar.brand} {selectedCar.model} {selectedCar.year}
                </h2>
              </div>

              <button
                type="button"
                onClick={() => onSelectCar(null)}
                aria-label="إغلاق"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left/Right Main: 360 Interactive Viewer & Inspection Report */}
              <div className="lg:col-span-7 space-y-6">
                <div className="space-y-3">
                  <div className="relative aspect-[16/10] rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-800">
                    <div
                      className="w-full h-full transition-transform duration-300"
                      style={{
                        transform: `perspective(1000px) rotateY(${VIEW_ANGLES[angleIndex].rotateY}deg) scale(${VIEW_ANGLES[angleIndex].scale})`,
                      }}
                    >
                      <SafeImage
                        src={
                          angleIndex === 3
                            ? '/src/assets/images/car_inspection_bay_1795476300338.jpg'
                            : selectedCar.imageUrl
                        }
                        alt={`${selectedCar.brand} ${selectedCar.model}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute top-3 right-3 px-3 py-1.5 rounded-lg bg-slate-950/75 text-white text-xs font-bold inline-flex items-center gap-1.5">
                      <RotateCw className="w-3.5 h-3.5 text-[#F59E0B]" />
                      معرض تفاعلي 360° — {VIEW_ANGLES[angleIndex].label}
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    {VIEW_ANGLES.map((angle, idx) => (
                      <button
                        key={angle.id}
                        type="button"
                        onClick={() => setAngleIndex(idx)}
                        className={`px-2 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          angleIndex === idx
                            ? 'bg-[#1E40AF] text-white border-[#1E40AF]'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {angle.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Inspection Report Summary */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-[#1E40AF] dark:text-blue-400" />
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                        ملخص تقرير الفحص الفني (150 نقطة)
                      </h3>
                    </div>
                    {selectedCar.latestInspection ? (
                      <span className="text-lg font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                        {selectedCar.latestInspection.overallScore}%
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-[#F59E0B]">قيد الفحص</span>
                    )}
                  </div>

                  {selectedCar.latestInspection ? (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                      <div className="py-2.5 flex flex-col sm:flex-row sm:justify-between gap-1">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">
                          حالة الموتور
                        </span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {selectedCar.latestInspection.engineStatus}
                        </span>
                      </div>
                      <div className="py-2.5 flex flex-col sm:flex-row sm:justify-between gap-1">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">
                          الفتيس وناقل الحركة
                        </span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {selectedCar.latestInspection.transmissionStatus}
                        </span>
                      </div>
                      <div className="py-2.5 flex flex-col sm:flex-row sm:justify-between gap-1">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">
                          الشاسيه والدواخل
                        </span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {selectedCar.latestInspection.chassisStatus}
                        </span>
                      </div>
                      <div className="py-2.5 flex flex-col sm:flex-row sm:justify-between gap-1">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">
                          الدهان والبودي
                        </span>
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {selectedCar.latestInspection.paintStatus}
                        </span>
                      </div>
                      <div className="py-2.5 flex items-center justify-between gap-2">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">
                          كفاءة البطارية (SoH)
                        </span>
                        <span className="font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                          {selectedCar.latestInspection.batteryHealth}%
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      هذه السيارة في انتظار إتمام الفحص الميداني من مهندس الفحص الفني المعتمد.
                    </p>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      const vin = selectedCar.vinNumber;
                      onSelectCar(null);
                      onOpenPassport(vin);
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <FileCheck2 className="w-4 h-4 text-[#1E40AF] dark:text-blue-400" />
                    عرض السجل التاريخي للصيانة وجواز السفر الرقمي ({selectedCar.verifiedServiceCount} سجل)
                  </button>
                </div>
              </div>

              {/* Purchase Module & Installment Calculator */}
              <div className="lg:col-span-5 space-y-5">
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      السعر النقدي
                    </span>
                    <span className="text-2xl font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                      {selectedCar.price.toLocaleString('ar-EG')} ج.م
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">عداد الكيلومترات</span>
                      <span className="font-bold text-slate-900 dark:text-white tabular-nums">
                        {selectedCar.mileage.toLocaleString('ar-EG')} كم
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">المدينة</span>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {selectedCar.city}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">نوع الوقود / الطاقة</span>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {selectedCar.fuelType}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">ناقل الحركة</span>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {selectedCar.transmission}
                      </span>
                    </div>
                    {selectedCar.batteryCapacityKwh && (
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 block">سعة البطارية</span>
                        <span className="font-bold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                          {selectedCar.batteryCapacityKwh} kWh
                        </span>
                      </div>
                    )}
                    {selectedCar.rangeKm && (
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 block">مدى الشحنة</span>
                        <span className="font-bold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                          {selectedCar.rangeKm} كم
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Built-in Installment Calculator */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-5 h-5 text-[#F59E0B]" />
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                      حاسبة التقسيط المدمجة
                    </h3>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <div className="flex justify-between font-bold mb-1">
                        <span>المقدم ({downPaymentPct}%)</span>
                        <span className="tabular-nums">
                          {installmentCalc?.downPayment.toLocaleString('ar-EG')} ج.م
                        </span>
                      </div>
                      <input
                        type="range"
                        min={15}
                        max={60}
                        step={5}
                        value={downPaymentPct}
                        onChange={(e) => setDownPaymentPct(Number(e.target.value))}
                        className="w-full accent-[#1E40AF]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <label className="space-y-1 block">
                        <span className="text-slate-600 dark:text-slate-400 font-medium">
                          مدة التقسيط (شهر)
                        </span>
                        <select
                          value={months}
                          onChange={(e) => setMonths(Number(e.target.value))}
                          className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 font-bold tabular-nums"
                        >
                          <option value={12}>12 شهر</option>
                          <option value={24}>24 شهر</option>
                          <option value={36}>36 شهر</option>
                          <option value={48}>48 شهر</option>
                          <option value={60}>60 شهر</option>
                          <option value={84}>84 شهر</option>
                        </select>
                      </label>

                      <label className="space-y-1 block">
                        <span className="text-slate-600 dark:text-slate-400 font-medium">
                          الفائدة السنوية (%)
                        </span>
                        <input
                          type="number"
                          min={5}
                          max={30}
                          step={0.5}
                          value={annualRate}
                          onChange={(e) => setAnnualRate(Number(e.target.value))}
                          className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 font-bold tabular-nums"
                        />
                      </label>
                    </div>
                  </div>

                  {installmentCalc && (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                        القسط الشهري التقديري
                      </span>
                      <span className="text-xl font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                        {installmentCalc.monthlyPayment.toLocaleString('ar-EG')} ج.م/شهر
                      </span>
                    </div>
                  )}

                  <div className="pt-1 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
                    <span>البائع: {selectedCar.ownerName || 'مالك معتمد'}</span>
                    <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                      <Wrench className="w-3.5 h-3.5" />
                      تاريخ صيانة موثق
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Multi-Step Add Car Wizard + Fair Price Estimator */}
      {showAddWizard && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
          onClick={() => setShowAddWizard(false)}
        >
          <div
            className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  إضافة سيارة للبيع — خطوة {wizardStep} من 3
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  التسعير الذكي العادل + حجز فحص فني معتمد 150 نقطة
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddWizard(false)}
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePublishCar} className="p-6 space-y-5">
              {wizardError && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs font-bold">
                  {wizardError}
                </div>
              )}
              {wizardSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  {wizardSuccess}
                </div>
              )}

              {wizardStep === 1 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      التصنيف الرئيسي
                    </span>
                    <select
                      value={formCategory}
                      onChange={(e) =>
                        setFormCategory(e.target.value as Exclude<CarCategory, 'all'>)
                      }
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                    >
                      <option value="ev_hybrid">الكهربائية والهجينة (EV & Hybrid)</option>
                      <option value="chinese">السيارات الصينية الحديثة</option>
                      <option value="european">السيارات الأوروبية الفاخرة</option>
                      <option value="economy">الاقتصادية والاعتمادية</option>
                    </select>
                  </label>

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      رقم الشاسيه (VIN) — لجواز السفر الرقمي
                    </span>
                    <input
                      type="text"
                      value={formVin}
                      onChange={(e) => setFormVin(e.target.value)}
                      placeholder="مثال: LC0CE4CC5R0991122"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-xs"
                    />
                  </label>

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">الماركة</span>
                    <input
                      type="text"
                      required
                      value={formBrand}
                      onChange={(e) => setFormBrand(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                    />
                  </label>

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">الموديل</span>
                    <input
                      type="text"
                      required
                      value={formModel}
                      onChange={(e) => setFormModel(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                    />
                  </label>

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      سنة الصنع
                    </span>
                    <input
                      type="number"
                      min={2005}
                      max={2027}
                      required
                      value={formYear}
                      onChange={(e) => setFormYear(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 tabular-nums"
                    />
                  </label>

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      الكيلومترات الحالية
                    </span>
                    <input
                      type="number"
                      min={0}
                      required
                      value={formMileage}
                      onChange={(e) => setFormMileage(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 tabular-nums"
                    />
                  </label>

                  {formCategory === 'ev_hybrid' && (
                    <>
                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                          سعة البطارية (kWh)
                        </span>
                        <input
                          type="number"
                          step="0.5"
                          value={formBattery}
                          onChange={(e) => setFormBattery(Number(e.target.value))}
                          className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 tabular-nums"
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                          مدى الشحن (كم)
                        </span>
                        <input
                          type="number"
                          value={formRange}
                          onChange={(e) => setFormRange(Number(e.target.value))}
                          className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 tabular-nums"
                        />
                      </label>
                    </>
                  )}

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">المدينة</span>
                    <input
                      type="text"
                      value={formCity}
                      onChange={(e) => setFormCity(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                    />
                  </label>

                  <label className="space-y-1">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      ناقل الحركة
                    </span>
                    <input
                      type="text"
                      value={formTransmission}
                      onChange={(e) => setFormTransmission(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                    />
                  </label>
                </div>
              )}

              {wizardStep === 2 && (
                <div className="space-y-5">
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 font-extrabold text-sm text-slate-900 dark:text-white">
                        <Sparkles className="w-4 h-4 text-[#F59E0B]" />
                        أداة التسعير الذكي (Fair Price Estimator)
                      </div>
                      <button
                        type="button"
                        onClick={runFairPriceEstimator}
                        disabled={estimating}
                        className="px-3.5 py-1.5 rounded-lg bg-[#1E40AF] text-white text-xs font-bold cursor-pointer disabled:opacity-60"
                      >
                        {estimating ? 'جاري التقييم...' : 'احسب السعر العادل'}
                      </button>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-bold">
                        <span>حالة السيارة المتوقعة في الفحص الفني</span>
                        <span className="tabular-nums text-[#1E40AF] dark:text-blue-400">
                          {expectedScore}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={65}
                        max={100}
                        value={expectedScore}
                        onChange={(e) => setExpectedScore(Number(e.target.value))}
                        className="w-full accent-[#1E40AF]"
                      />
                    </div>

                    {estimate && (
                      <div className="pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2">
                        <div className="grid grid-cols-3 gap-3 text-center">
                          <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                            <div className="text-[11px] text-slate-500">أدنى نطاق</div>
                            <div className="text-sm font-bold tabular-nums">
                              {estimate.minPrice.toLocaleString('ar-EG')}
                            </div>
                          </div>
                          <div className="p-2.5 rounded-lg bg-[#1E40AF] text-white">
                            <div className="text-[11px] text-blue-100">السعر العادل المقترح</div>
                            <div className="text-base font-extrabold tabular-nums">
                              {estimate.fairPrice.toLocaleString('ar-EG')} ج.م
                            </div>
                          </div>
                          <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                            <div className="text-[11px] text-slate-500">أعلى نطاق</div>
                            <div className="text-sm font-bold tabular-nums">
                              {estimate.maxPrice.toLocaleString('ar-EG')}
                            </div>
                          </div>
                        </div>
                        <div className="text-xs text-slate-600 dark:text-slate-300">
                          عوامل التقييم: {estimate.factors.join(' · ')}
                        </div>
                      </div>
                    )}
                  </div>

                  <label className="space-y-1 block">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      السعر النهائي المطلوب للبيع (ج.م)
                    </span>
                    <input
                      type="number"
                      required
                      min={100000}
                      value={formPrice}
                      onChange={(e) => setFormPrice(Number(e.target.value))}
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-lg font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums"
                    />
                  </label>
                </div>
              )}

              {wizardStep === 3 && (
                <div className="space-y-4">
                  <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer bg-slate-50 dark:bg-slate-800/50">
                    <input
                      type="checkbox"
                      checked={requestInspection}
                      onChange={(e) => setRequestInspection(e.target.checked)}
                      className="mt-1 w-4 h-4 accent-[#1E40AF]"
                    />
                    <div className="space-y-1">
                      <div className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-[#F59E0B]" />
                        حجز فحص فني معتمد (150 نقطة) قبل النشر — موصى به
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                        يزيد الفحص الفني المعتمد من سرعة البيع بنسبة 3 أضعاف، ويضيف شارة الفحص وتقرير
                        الشاسيه والبطارية تلقائياً إلى بطاقة السيارة في السوق.
                      </p>
                    </div>
                  </label>

                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
                    <div className="font-bold text-slate-900 dark:text-white text-sm">
                      ملخص الإعلان: {formBrand} {formModel} {formYear}
                    </div>
                    <div className="text-slate-600 dark:text-slate-400">
                      السعر: {formPrice.toLocaleString('ar-EG')} ج.م · العداد:{' '}
                      {formMileage.toLocaleString('ar-EG')} كم · المدينة: {formCity}
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-2 flex items-center justify-between gap-3 border-t border-slate-100 dark:border-slate-800">
                {wizardStep > 1 ? (
                  <button
                    type="button"
                    onClick={() => setWizardStep((s) => (s === 3 ? 2 : 1))}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold cursor-pointer"
                  >
                    السابق
                  </button>
                ) : (
                  <div />
                )}

                {wizardStep < 3 ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (wizardStep === 1 && !estimate) {
                        void runFairPriceEstimator();
                      }
                      setWizardStep((s) => (s === 1 ? 2 : 3));
                    }}
                    className="px-6 py-2.5 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-xs font-bold cursor-pointer"
                  >
                    التالي
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={submittingCar}
                    className="px-6 py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-slate-950 text-xs font-extrabold cursor-pointer disabled:opacity-60"
                  >
                    {!firebaseUser
                      ? 'سجّل الدخول لنشر السيارة'
                      : submittingCar
                        ? 'جاري الحفظ...'
                        : 'تأكيد ونشر السيارة'}
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
