import React, { useMemo, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  ClipboardCheck,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  INSPECTION_DOMAINS,
  PointStatus,
  TOTAL_INSPECTION_POINTS,
} from '../data/inspectionCatalog';
import { CarListingDTO } from '../types';

interface InspectionFormViewProps {
  cars: CarListingDTO[];
  onInspectionSubmitted: () => Promise<void>;
}

function buildInitialStatuses(): Record<string, PointStatus> {
  const map: Record<string, PointStatus> = {};
  for (const domain of INSPECTION_DOMAINS) {
    for (const pt of domain.points) {
      map[pt.id] = 'pass';
    }
  }
  return map;
}

export function InspectionFormView({ cars, onInspectionSubmitted }: InspectionFormViewProps) {
  const { firebaseUser, profile, signInWithGoogle, authFetch } = useAuth();

  const sortedCars = useMemo(() => {
    return [...cars].sort((a, b) => Number(a.isVerified) - Number(b.isVerified));
  }, [cars]);

  const [selectedCarId, setSelectedCarId] = useState<number>(sortedCars[0]?.id ?? 0);
  const [activeDomainKey, setActiveDomainKey] = useState(INSPECTION_DOMAINS[0].key);
  const [statuses, setStatuses] = useState<Record<string, PointStatus>>(() =>
    buildInitialStatuses()
  );
  const [notes, setNotes] = useState(
    'تم فحص السيارة على الرافعة وجهاز كشف الأعطال OBD-II وقياس سمك الدهان بالليزر.'
  );
  const [photos, setPhotos] = useState<Array<{ name: string; preview: string }>>([]);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const canSubmit = profile?.role === 'inspector' || profile?.role === 'admin';

  const domainScores = useMemo(() => {
    const scores: Record<string, { score: number; pass: number; warn: number; fail: number }> = {};
    for (const domain of INSPECTION_DOMAINS) {
      let earned = 0;
      let pass = 0;
      let warn = 0;
      let fail = 0;
      for (const pt of domain.points) {
        const st = statuses[pt.id] ?? 'pass';
        if (st === 'pass') {
          earned += 1;
          pass += 1;
        } else if (st === 'warning') {
          earned += 0.6;
          warn += 1;
        } else {
          fail += 1;
        }
      }
      scores[domain.key] = {
        score: Math.round((earned / domain.points.length) * 100),
        pass,
        warn,
        fail,
      };
    }
    return scores;
  }, [statuses]);

  const overallScore = useMemo(() => {
    let total = 0;
    for (const domain of INSPECTION_DOMAINS) {
      total += (domainScores[domain.key]?.score ?? 100) * domain.weight;
    }
    return Math.round(total);
  }, [domainScores]);

  const summaryCounts = useMemo(() => {
    let pass = 0;
    let warn = 0;
    let fail = 0;
    Object.values(statuses).forEach((s) => {
      if (s === 'pass') pass += 1;
      else if (s === 'warning') warn += 1;
      else fail += 1;
    });
    return { pass, warn, fail };
  }, [statuses]);

  const activeDomain =
    INSPECTION_DOMAINS.find((d) => d.key === activeDomainKey) || INSPECTION_DOMAINS[0];

  const setPoint = (id: string, status: PointStatus) => {
    setStatuses((prev) => ({ ...prev, [id]: status }));
  };

  const setDomainAll = (status: PointStatus) => {
    setStatuses((prev) => {
      const next = { ...prev };
      for (const pt of activeDomain.points) {
        next[pt.id] = status;
      }
      return next;
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const list = Array.from(files).slice(0, 4 - photos.length);
    for (const file of list) {
      if (!file.type.startsWith('image/') || file.size > 3 * 1024 * 1024) continue;
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPhotos((prev) => [...prev.slice(0, 3), { name: file.name, preview: reader.result as string }]);
        }
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const describeScore = (score: number, label: string) => {
    if (score >= 92) return `ممتاز — ${label} بحالة المصنع (${score}%)`;
    if (score >= 80) return `جيد جداً — ملاحظات بسيطة في ${label} (${score}%)`;
    if (score >= 65) return `مقبول — يحتاج صيانة في ${label} (${score}%)`;
    return `ضعيف — أعطال مؤثرة في ${label} (${score}%)`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    const carId = selectedCarId || sortedCars[0]?.id;
    if (!carId) {
      setErrorMsg('يرجى اختيار سيارة للفحص.');
      return;
    }

    setSubmitting(true);
    try {
      const engScore = domainScores.engine?.score ?? 95;
      const chsScore = domainScores.chassis?.score ?? 95;
      const pntScore = domainScores.paint?.score ?? 92;
      const batScore = domainScores.battery?.score ?? 96;

      const res = await authFetch('/api/inspections', {
        method: 'POST',
        body: JSON.stringify({
          carId: Number(carId),
          overallScore,
          engineStatus: describeScore(engScore, 'المحرك'),
          transmissionStatus: describeScore(engScore, 'الفتيس وناقل الحركة'),
          chassisStatus: describeScore(chsScore, 'الشاسيه والدواخل'),
          paintStatus: describeScore(pntScore, 'الدهان والبودي'),
          batteryHealth: batScore,
          checklistJson: JSON.stringify({
            totalPoints: TOTAL_INSPECTION_POINTS,
            summary: summaryCounts,
            domainScores,
            photoCount: photos.length,
          }),
          notes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر إصدار تقرير الفحص.');

      setSuccessMsg(
        `تم إصدار شهادة الفحص المعتمدة بنجاح بنتيجة ${overallScore}% وتوثيق السيارة في السوق وجواز السفر الرقمي.`
      );
      await onInspectionSubmitted();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Inspector Header & Score Strip */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-bold text-[#1E40AF] dark:text-blue-400 inline-flex items-center gap-1.5">
              <ClipboardCheck className="w-4 h-4" />
              بوابة مهندس الفحص الفني المعتمد
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
              نموذج الفحص الفني التفاعلي ({TOTAL_INSPECTION_POINTS} نقطة)
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <div>
              <div className="text-xs text-slate-500">التقييم الإجمالي الفوري</div>
              <div className="text-3xl font-extrabold text-[#1E40AF] dark:text-blue-400 tabular-nums">
                {overallScore}%
              </div>
            </div>
            <div className="text-xs space-y-1 border-r border-slate-200 dark:border-slate-800 pr-4 tabular-nums">
              <div className="text-emerald-600 dark:text-emerald-400 font-bold">
                سليم: {summaryCounts.pass} نقطة
              </div>
              <div className="text-[#F59E0B] font-bold">ملاحظة: {summaryCounts.warn} نقطة</div>
              <div className="text-red-600 dark:text-red-400 font-bold">
                عطل: {summaryCounts.fail} نقطة
              </div>
            </div>
          </div>
        </div>

        {/* Vehicle Selection */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
          <label className="md:col-span-7 space-y-1">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
              اختر السيارة المطلوب فحصها وإصدار تقريرها
            </span>
            <select
              value={selectedCarId || sortedCars[0]?.id || ''}
              onChange={(e) => setSelectedCarId(Number(e.target.value))}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-bold"
            >
              {sortedCars.map((c) => (
                <option key={c.id} value={c.id}>
                  {!c.isVerified ? '[بانتظار الفحص] ' : '[إعادة فحص] '}
                  {c.brand} {c.model} {c.year} — VIN: {c.vinNumber}
                </option>
              ))}
            </select>
          </label>

          <div className="md:col-span-5 flex items-end justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>
              المهندس المسؤول:{' '}
              <strong className="text-slate-900 dark:text-white">
                {profile?.name || 'سجّل الدخول كمهندس فحص'}
              </strong>
            </span>
            <span className="font-bold text-[#1E40AF] dark:text-blue-400">
              {canSubmit ? 'صلاحية الاعتماد مفعلة' : 'وضع المعاينة التفاعلية'}
            </span>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-sm font-bold">
          {errorMsg}
        </div>
      )}
      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-sm font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          {successMsg}
        </div>
      )}

      {/* 6 Domain Selector Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {INSPECTION_DOMAINS.map((domain) => {
          const active = domain.key === activeDomainKey;
          const sc = domainScores[domain.key]?.score ?? 100;
          return (
            <button
              key={domain.key}
              type="button"
              onClick={() => setActiveDomainKey(domain.key)}
              className={`p-3 rounded-xl border text-right transition-colors cursor-pointer space-y-1 ${
                active
                  ? 'bg-[#1E40AF] text-white border-[#1E40AF]'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-[#1E40AF]/40'
              }`}
            >
              <div className="text-xs font-bold leading-snug">{domain.title}</div>
              <div
                className={`text-sm font-extrabold tabular-nums ${
                  active ? 'text-amber-300' : 'text-[#1E40AF] dark:text-blue-400'
                }`}
              >
                {sc}%
              </div>
            </button>
          );
        })}
      </div>

      {/* Checklist Points Panel */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              {activeDomain.title}
            </h3>
            <p className="text-xs text-slate-500">
              اضغط لتقييم كل نقطة بدقة (سليم / ملاحظة / عطل) ليتم احتساب التقييم الموزون تلقائياً
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setDomainAll('pass')}
              className="px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold cursor-pointer"
            >
              اعتماد القسم سليم
            </button>
            <button
              type="button"
              onClick={() => setDomainAll('warning')}
              className="px-3 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 text-xs font-bold cursor-pointer"
            >
              ملاحظات على القسم
            </button>
          </div>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[420px] overflow-y-auto pl-1">
          {activeDomain.points.map((pt, idx) => {
            const val = statuses[pt.id] ?? 'pass';
            return (
              <div
                key={pt.id}
                className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <span className="text-[11px] font-mono text-slate-400 w-6 tabular-nums">
                    {String(idx + 1).padStart(2, '0')}
                  </span>
                  <span>{pt.label}</span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {(['pass', 'warning', 'fail'] as PointStatus[]).map((st) => {
                    const selected = val === st;
                    const label = st === 'pass' ? 'سليم' : st === 'warning' ? 'ملاحظة' : 'عطل';
                    const activeClasses =
                      st === 'pass'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : st === 'warning'
                          ? 'bg-[#F59E0B] text-slate-950 border-[#F59E0B]'
                          : 'bg-red-600 text-white border-red-600';
                    return (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setPoint(pt.id, st)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          selected
                            ? activeClasses
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Photo Upload + Engineering Notes + Final Submit */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              صور الفحص الميداني (الموتور، الشاسيه، العداد، جهاز القياس)
            </span>
            <label className="flex items-center justify-center gap-2 p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 hover:border-[#1E40AF] cursor-pointer text-xs font-bold text-slate-600 dark:text-slate-300">
              <Camera className="w-4 h-4 text-[#1E40AF] dark:text-blue-400" />
              رفع صور الفحص (حتى 4 صور)
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </label>
            {photos.length > 0 && (
              <div className="grid grid-cols-4 gap-2 pt-2">
                {photos.map((photo, idx) => (
                  <div
                    key={`${photo.name}-${idx}`}
                    className="relative aspect-square rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700"
                  >
                    <img
                      src={photo.preview}
                      alt={photo.name}
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setPhotos((prev) => prev.filter((_, i) => i !== idx))}
                      className="absolute top-1 left-1 p-1 rounded bg-slate-950/75 text-white cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <label className="space-y-2 block">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              توصيات وملاحظات مهندس الفحص النهائية
            </span>
            <textarea
              rows={4}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm"
            />
          </label>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="text-xs text-slate-600 dark:text-slate-400">
            عند الإصدار: يتم تفعيل شارة الفحص ({overallScore}%) في السوق وإضافة التقرير تلقائياً إلى
            جواز السفر الرقمي (VIN).
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-3 rounded-xl bg-[#1E40AF] hover:bg-[#1E3A8A] text-white text-sm font-extrabold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-60 whitespace-nowrap"
          >
            <ShieldCheck className="w-4 h-4 text-[#F59E0B]" />
            {!firebaseUser
              ? 'سجّل الدخول لإصدار التقرير المعتمد'
              : submitting
                ? 'جاري إصدار الشهادة...'
                : 'إصدار تقرير الفحص النهائي وتوثيق السيارة'}
          </button>
        </div>
      </div>
    </form>
  );
}
