import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { z } from 'zod';
import {
  adminUpdateUserRole,
  createCarListing,
  createEmergencyRequest,
  createMaintenanceBooking,
  getAdminOverview,
  getCarById,
  getDigitalPassportByVin,
  listEmergencyRequests,
  listMaintenanceBookings,
  listMarketplaceCars,
  submitInspectionReport,
  updateEmergencyStatus,
  updateMaintenanceBookingStatus,
  updateUserProfile,
} from './src/db/repository.ts';
import { AuthRequest, requireAuth, requireRole } from './src/middleware/auth.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ALLOWED_IMAGE_PATHS = new Set([
  '/src/assets/images/hero_automotive_showroom_1795476301102.jpg',
  '/src/assets/images/car_ev_suv_1795476299976.jpg',
  '/src/assets/images/car_chinese_sedan_1795476300085.jpg',
  '/src/assets/images/car_european_luxury_1795476300560.jpg',
  '/src/assets/images/car_economy_hatch_1795476301524.jpg',
  '/src/assets/images/car_inspection_bay_1795476300338.jpg',
]);

function defaultImageForCategory(category: string): string {
  switch (category) {
    case 'ev_hybrid':
      return '/src/assets/images/car_ev_suv_1795476299976.jpg';
    case 'chinese':
      return '/src/assets/images/car_chinese_sedan_1795476300085.jpg';
    case 'european':
      return '/src/assets/images/car_european_luxury_1795476300560.jpg';
    default:
      return '/src/assets/images/car_economy_hatch_1795476301524.jpg';
  }
}

const createCarSchema = z.object({
  vinNumber: z.string().min(10).max(20),
  brand: z.string().min(2).max(60),
  model: z.string().min(1).max(80),
  year: z.number().int().min(2005).max(2027),
  category: z.enum(['ev_hybrid', 'chinese', 'european', 'economy']),
  price: z.number().int().min(100000).max(50000000),
  mileage: z.number().int().min(0).max(1000000),
  requestInspection: z.boolean().default(true),
  batteryCapacityKwh: z.number().min(10).max(200).nullable().optional(),
  rangeKm: z.number().int().min(80).max(1200).nullable().optional(),
  transmission: z.string().max(60).optional(),
  fuelType: z.string().max(60).optional(),
  city: z.string().max(60).optional(),
  imageUrl: z.string().max(300).optional(),
  dailyAvgKm: z.number().int().min(5).max(500).optional(),
  licenseExpiry: z.string().max(30).nullable().optional(),
  insuranceExpiry: z.string().max(30).nullable().optional(),
});

const pricingEstimateSchema = z.object({
  brand: z.string().min(1).max(60),
  model: z.string().min(1).max(80),
  year: z.number().int().min(2005).max(2027),
  category: z.enum(['ev_hybrid', 'chinese', 'european', 'economy']),
  mileage: z.number().int().min(0).max(1000000),
  inspectionScore: z.number().min(50).max(100).default(92),
  batteryCapacityKwh: z.number().min(0).max(200).nullable().optional(),
});

const inspectionSubmitSchema = z.object({
  carId: z.number().int().positive(),
  overallScore: z.number().int().min(0).max(100),
  engineStatus: z.string().min(2).max(200),
  transmissionStatus: z.string().min(2).max(200),
  chassisStatus: z.string().min(2).max(200),
  paintStatus: z.string().min(2).max(200),
  batteryHealth: z.number().int().min(0).max(100),
  checklistJson: z.string().max(120000).default('{}'),
  notes: z.string().max(2000).default(''),
});

const bookingCreateSchema = z.object({
  carId: z.number().int().positive(),
  serviceType: z.string().min(3).max(120),
  locationType: z.enum(['mobile_gps', 'service_center']),
  providerName: z.string().min(2).max(120),
  addressText: z.string().min(3).max(240),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  scheduledAt: z.string().min(8).max(40),
  totalCost: z.number().min(0).max(1000000),
});

const bookingPatchSchema = z.object({
  status: z.enum(['pending', 'confirmed', 'in_progress', 'completed', 'cancelled']),
  totalCost: z.number().min(0).max(1000000).optional(),
  partsReplaced: z.string().max(500).optional(),
  mileageAtService: z.number().int().min(0).max(1000000).optional(),
});

const emergencyCreateSchema = z.object({
  carId: z.number().int().positive().nullable().optional(),
  issueType: z.enum(['tow_truck', 'battery', 'tire', 'fuel', 'electrical']),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  addressText: z.string().min(3).max(240),
});

const emergencyPatchSchema = z.object({
  status: z.enum(['dispatched', 'en_route', 'arrived', 'resolved']),
});

const adminRoleSchema = z.object({
  role: z.enum(['user', 'inspector', 'provider', 'admin']),
  isVerifiedProvider: z.boolean().optional(),
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '5mb' }));

  // 1. Authenticated Current User Profile
  app.get('/api/me', requireAuth, async (req: AuthRequest, res) => {
    try {
      const dbUser = req.dbUser!;
      const ownedCars = await listMarketplaceCars({ ownerId: dbUser.id, includePending: true });
      const bookings = await listMaintenanceBookings({ userId: dbUser.id, role: dbUser.role });
      const emergencies = await listEmergencyRequests({ userId: dbUser.id, role: dbUser.role });

      res.json({
        user: dbUser,
        ownedCars,
        bookings,
        emergencies,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحميل بيانات المستخدم.' });
    }
  });

  app.patch('/api/me/profile', requireAuth, async (req: AuthRequest, res) => {
    try {
      const parsed = z
        .object({
          name: z.string().min(2).max(80).optional(),
          phone: z.string().max(25).optional(),
        })
        .safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: 'البيانات المدخلة غير صالحة.' });
      }
      const updated = await updateUserProfile(req.dbUser!.id, parsed.data);
      res.json({ user: updated });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحديث الملف الشخصي.' });
    }
  });

  // 2. Dynamic Category Engine & Verified Marketplace
  app.get('/api/cars', async (req, res) => {
    try {
      const category = typeof req.query.category === 'string' ? req.query.category : 'all';
      const minBattery = req.query.minBattery ? Number(req.query.minBattery) : undefined;
      const minRange = req.query.minRange ? Number(req.query.minRange) : undefined;
      const maxPrice = req.query.maxPrice ? Number(req.query.maxPrice) : undefined;
      const search = typeof req.query.search === 'string' ? req.query.search : undefined;
      const includePending = req.query.includePending === 'true';

      const items = await listMarketplaceCars({
        category,
        minBattery: Number.isFinite(minBattery) ? minBattery : undefined,
        minRange: Number.isFinite(minRange) ? minRange : undefined,
        maxPrice: Number.isFinite(maxPrice) ? maxPrice : undefined,
        search,
        includePending,
      });

      res.json({ cars: items });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحميل سوق السيارات.' });
    }
  });

  app.get('/api/cars/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: 'معرف السيارة غير صالح.' });
      }
      const car = await getCarById(id);
      if (!car) return res.status(404).json({ error: 'السيارة غير موجودة.' });
      res.json({ car });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحميل بيانات السيارة.' });
    }
  });

  app.post('/api/cars', requireAuth, async (req: AuthRequest, res) => {
    try {
      const parsed = createCarSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: 'يرجى التأكد من صحة جميع حقول السيارة ورقم الشاسيه.',
        });
      }
      const safeImage =
        parsed.data.imageUrl && ALLOWED_IMAGE_PATHS.has(parsed.data.imageUrl)
          ? parsed.data.imageUrl
          : defaultImageForCategory(parsed.data.category);

      const created = await createCarListing({
        ownerId: req.dbUser!.id,
        vinNumber: parsed.data.vinNumber,
        brand: parsed.data.brand,
        model: parsed.data.model,
        year: parsed.data.year,
        category: parsed.data.category,
        price: parsed.data.price,
        mileage: parsed.data.mileage,
        requestInspection: parsed.data.requestInspection,
        batteryCapacityKwh: parsed.data.batteryCapacityKwh ?? null,
        rangeKm: parsed.data.rangeKm ?? null,
        transmission: parsed.data.transmission,
        fuelType: parsed.data.fuelType,
        city: parsed.data.city,
        imageUrl: safeImage,
        dailyAvgKm: parsed.data.dailyAvgKm,
        licenseExpiry: parsed.data.licenseExpiry,
        insuranceExpiry: parsed.data.insuranceExpiry,
      });

      res.status(201).json({ car: created });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر نشر إعلان السيارة.' });
    }
  });

  // 3. Fair Price Estimator
  app.post('/api/pricing/estimate', (req, res) => {
    const parsed = pricingEstimateSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'يرجى إدخال بيانات السيارة بشكل صحيح لحساب السعر العادل.' });
    }
    const { category, year, mileage, inspectionScore, batteryCapacityKwh } = parsed.data;

    const categoryBase: Record<string, number> = {
      ev_hybrid: 2150000,
      chinese: 1550000,
      european: 4900000,
      economy: 1080000,
    };

    let price = categoryBase[category] ?? 1300000;
    const age = Math.max(0, 2026 - year);
    price *= Math.pow(0.92, age);

    const mileageFactor = Math.max(0.68, 1 - (mileage / 250000) * 0.32);
    price *= mileageFactor;

    const inspectionMultiplier = 0.82 + (inspectionScore / 100) * 0.22;
    price *= inspectionMultiplier;

    if (category === 'ev_hybrid' && batteryCapacityKwh && batteryCapacityKwh > 70) {
      price += (batteryCapacityKwh - 70) * 14000;
    }

    const fairPrice = Math.round(price / 10000) * 10000;
    const minPrice = Math.round((fairPrice * 0.94) / 10000) * 10000;
    const maxPrice = Math.round((fairPrice * 1.06) / 10000) * 10000;

    const factors = [
      `الفئة السوقية وسنة الصنع (${year})`,
      `استهلاك العداد (${mileage.toLocaleString('ar-EG')} كم)`,
      `تقييم الفحص الفني المتوقع (${inspectionScore}%)`,
    ];
    if (category === 'ev_hybrid' && batteryCapacityKwh) {
      factors.push(`سعة البطارية (${batteryCapacityKwh} kWh) وكفاءة المدى`);
    }

    res.json({
      minPrice,
      fairPrice,
      maxPrice,
      confidence: 94,
      factors,
    });
  });

  // 4. Inspector 150-Point Technical Inspection Endpoints
  app.get(
    '/api/inspections/pending',
    requireAuth,
    requireRole(['inspector', 'admin']),
    async (_req, res) => {
      try {
        const all = await listMarketplaceCars({ includePending: true });
        res.json({
          queue: all.filter((c) => c.status === 'pending_inspection' || !c.isVerified),
          allCars: all,
        });
      } catch (error: any) {
        res.status(500).json({ error: error.message || 'تعذر تحميل طلبات الفحص الفني.' });
      }
    }
  );

  app.post(
    '/api/inspections',
    requireAuth,
    requireRole(['inspector', 'admin']),
    async (req: AuthRequest, res) => {
      try {
        const parsed = inspectionSubmitSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: 'يرجى استكمال جميع بنود تقرير الفحص الفني.' });
        }

        const report = await submitInspectionReport({
          carId: parsed.data.carId,
          inspectorId: req.dbUser!.id,
          inspectorName: req.dbUser!.name,
          overallScore: parsed.data.overallScore,
          engineStatus: parsed.data.engineStatus,
          transmissionStatus: parsed.data.transmissionStatus,
          chassisStatus: parsed.data.chassisStatus,
          paintStatus: parsed.data.paintStatus,
          batteryHealth: parsed.data.batteryHealth,
          checklistJson: parsed.data.checklistJson,
          notes: parsed.data.notes,
        });

        res.status(201).json({ report });
      } catch (error: any) {
        res.status(500).json({ error: error.message || 'تعذر إصدار تقرير الفحص الفني.' });
      }
    }
  );

  // 5. Smart Maintenance Hub Endpoints
  app.get('/api/maintenance/bookings', requireAuth, async (req: AuthRequest, res) => {
    try {
      const bookings = await listMaintenanceBookings({
        userId: req.dbUser!.id,
        role: req.dbUser!.role,
      });
      res.json({ bookings });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحميل حجوزات الصيانة.' });
    }
  });

  app.post('/api/maintenance/bookings', requireAuth, async (req: AuthRequest, res) => {
    try {
      const parsed = bookingCreateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: 'بيانات حجز الصيانة غير مكتملة أو غير صالحة.' });
      }

      const scheduledDate = new Date(parsed.data.scheduledAt);
      if (Number.isNaN(scheduledDate.getTime())) {
        return res.status(400).json({ error: 'تاريخ الموعد غير صالح.' });
      }

      const booking = await createMaintenanceBooking({
        userId: req.dbUser!.id,
        carId: parsed.data.carId,
        serviceType: parsed.data.serviceType,
        locationType: parsed.data.locationType,
        providerName: parsed.data.providerName,
        addressText: parsed.data.addressText,
        lat: parsed.data.lat,
        lng: parsed.data.lng,
        scheduledAt: scheduledDate,
        totalCost: parsed.data.totalCost,
      });

      res.status(201).json({ booking });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تأكيد حجز الصيانة.' });
    }
  });

  app.patch(
    '/api/maintenance/bookings/:id',
    requireAuth,
    requireRole(['provider', 'admin']),
    async (req: AuthRequest, res) => {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) {
          return res.status(400).json({ error: 'رقم الحجز غير صالح.' });
        }

        const parsed = bookingPatchSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: 'بيانات تحديث الصيانة غير صالحة.' });
        }

        const updated = await updateMaintenanceBookingStatus({
          bookingId: id,
          status: parsed.data.status,
          totalCost: parsed.data.totalCost,
          partsReplaced: parsed.data.partsReplaced,
          mileageAtService: parsed.data.mileageAtService,
          providerLabel: req.dbUser!.name,
        });

        if (!updated) {
          return res.status(404).json({ error: 'الحجز غير موجود.' });
        }

        res.json({ booking: updated });
      } catch (error: any) {
        res.status(500).json({ error: error.message || 'تعذر تحديث حالة الصيانة.' });
      }
    }
  );

  // 6. Car Digital Passport (VIN History)
  app.get('/api/passport/:vin', async (req, res) => {
    try {
      const vin = req.params.vin;
      if (!vin || vin.length < 6) {
        return res.status(400).json({ error: 'يرجى إدخال رقم شاسيه (VIN) صحيح.' });
      }

      const passport = await getDigitalPassportByVin(vin);
      if (!passport) {
        return res.status(404).json({ error: 'لم يتم العثور على سيارة مسجلة بهذا الرقم.' });
      }

      res.json(passport);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر البحث في جواز السفر الرقمي.' });
    }
  });

  // 7. Road Emergency SOS Endpoints
  app.get('/api/emergency', requireAuth, async (req: AuthRequest, res) => {
    try {
      const emergencies = await listEmergencyRequests({
        userId: req.dbUser!.id,
        role: req.dbUser!.role,
      });
      res.json({ emergencies });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحميل بلاغات الطوارئ.' });
    }
  });

  app.post('/api/emergency', requireAuth, async (req: AuthRequest, res) => {
    try {
      const parsed = emergencyCreateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: 'يرجى تحديد نوع العطل والموقع الجغرافي.' });
      }

      const created = await createEmergencyRequest({
        userId: req.dbUser!.id,
        carId: parsed.data.carId ?? null,
        issueType: parsed.data.issueType,
        lat: parsed.data.lat,
        lng: parsed.data.lng,
        addressText: parsed.data.addressText,
      });

      res.status(201).json({ emergency: created });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر إرسال طلب الإنقاذ.' });
    }
  });

  app.patch(
    '/api/emergency/:id',
    requireAuth,
    requireRole(['provider', 'admin']),
    async (req, res) => {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) {
          return res.status(400).json({ error: 'رقم البلاغ غير صالح.' });
        }
        const parsed = emergencyPatchSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: 'الحالة غير صالحة.' });
        }

        const updated = await updateEmergencyStatus(id, parsed.data.status);
        if (!updated) return res.status(404).json({ error: 'البلاغ غير موجود.' });
        res.json({ emergency: updated });
      } catch (error: any) {
        res.status(500).json({ error: error.message || 'تعذر تحديث حالة البلاغ.' });
      }
    }
  );

  // 8. Super Admin Dashboard Endpoints
  app.get('/api/admin/overview', requireAuth, requireRole(['admin']), async (_req, res) => {
    try {
      const overview = await getAdminOverview();
      res.json(overview);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'تعذر تحميل تقارير الإدارة.' });
    }
  });

  app.patch(
    '/api/admin/users/:id/role',
    requireAuth,
    requireRole(['admin']),
    async (req, res) => {
      try {
        const id = Number(req.params.id);
        if (!Number.isInteger(id) || id <= 0) {
          return res.status(400).json({ error: 'معرف المستخدم غير صالح.' });
        }

        const parsed = adminRoleSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: 'الصلاحية المختارة غير صالحة.' });
        }

        const updated = await adminUpdateUserRole(
          id,
          parsed.data.role,
          parsed.data.isVerifiedProvider
        );
        if (!updated) return res.status(404).json({ error: 'المستخدم غير موجود.' });
        res.json({ user: updated });
      } catch (error: any) {
        res.status(500).json({ error: error.message || 'تعذر تعديل صلاحية المستخدم.' });
      }
    }
  );

  // Vite Dev Middleware or Static Production Build
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MotorTrust server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
